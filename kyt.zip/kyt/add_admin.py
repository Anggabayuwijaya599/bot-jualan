import sqlite3
import os

# --- KONFIGURASI ---
ID_BARU = "7319690771"  # ID Telegram Kamu
DB_PATH = "/usr/bin/kyt/database.db" # Lokasi Database yang sudah ketemu
# -------------------

print(f"📂 Membuka database di: {DB_PATH}")

if not os.path.exists(DB_PATH):
    print("❌ Error: File database tidak ditemukan di lokasi tersebut!")
    exit()

try:
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # 1. Cek/Buat Tabel Admin (Jaga-jaga jika tabel belum ada)
    c.execute("CREATE TABLE IF NOT EXISTS admin (user_id)")

    # 2. Cek apakah ID sudah ada?
    c.execute("SELECT user_id FROM admin WHERE user_id = ?", (ID_BARU,))
    row = c.fetchone()

    if row is None:
        # Jika belum ada, masukkan
        c.execute("INSERT INTO admin (user_id) VALUES (?)", (ID_BARU,))
        conn.commit()
        print(f"✅ SUKSES! ID {ID_BARU} berhasil ditambahkan jadi ADMIN.")
    else:
        # Jika sudah ada
        print(f"⚠️ INFO: ID {ID_BARU} sudah terdaftar sebagai admin sebelumnya.")

    # 3. Cek siapa saja admin yang terdaftar sekarang
    print("\n📋 DAFTAR ADMIN SAAT INI:")
    c.execute("SELECT user_id FROM admin")
    all_admins = c.fetchall()
    for idx, admin in enumerate(all_admins):
        print(f" {idx+1}. {admin[0]}")

    conn.close()

except Exception as e:
    print(f"❌ Error Database: {e}")