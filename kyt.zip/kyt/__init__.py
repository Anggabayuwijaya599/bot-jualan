from telethon import *
import datetime as DT
import requests, time, os, subprocess, re, sqlite3, sys, random, base64, json, math
import logging
from kyt.modules import config 

# =================================================================
# KONFIGURASI AWAL
# =================================================================
logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

# 1. LOAD VARIABEL DARI var.txt
try:
    var_path = "kyt/var.txt" 
    if not os.path.exists(var_path):
        var_path = "/usr/bin/kyt/var.txt" # Fallback path
    
    if os.path.exists(var_path):
        exec(open(var_path, "r").read())
    else:
        print("⚠️ var.txt tidak ditemukan.")

except Exception as e:
    print(f"⚠️ Error loading var.txt: {e}")

# Pastikan variable aman (Anti Crash)
if 'ADMIN' not in locals(): ADMIN = "0"
if 'BOT_TOKEN' not in locals(): 
    print("❌ BOT_TOKEN tidak ditemukan! Bot berhenti.")
    sys.exit()

# 2. START BOT TELEGRAM CLIENT
try:
    # Session name 'kyt_session' agar tidak perlu login ulang
    bot = TelegramClient("kyt_session", 6, "eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)
    print("✅ Telegram Client Berjalan...")
except Exception as e:
    print(f"❌ Error starting TelegramClient: {e}")
    sys.exit()

# 3. SETUP DATABASE
try:
    db_path = "kyt/database.db"
    if not os.path.exists("kyt"): os.makedirs("kyt") # Buat folder jika belum ada
    
    x = sqlite3.connect(db_path)
    c = x.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS admin (user_id)")
    
    # --- AUTO INJECT ADMIN (SUPPORT MULTI ID) ---
    # Kita pecah string ADMIN="ID1,ID2" menjadi list
    list_admin_txt = [x.strip() for x in str(ADMIN).split(',')]
    
    for adm_id in list_admin_txt:
        if adm_id and adm_id != "0":
            c.execute("SELECT user_id FROM admin WHERE user_id = ?", (adm_id,))
            if c.fetchone() is None:
                c.execute("INSERT INTO admin (user_id) VALUES (?)", (adm_id,))
                print(f"➕ Admin Ditambahkan ke DB: {adm_id}")
            
    x.commit()
    x.close()
except Exception as e:
    print(f"❌ Error init database: {e}")

# =================================================================
# FUNGSI GLOBAL PEMBANTU (INIT)
# =================================================================

def get_db():
    """Membuka koneksi database"""
    path = "kyt/database.db"
    if not os.path.exists(path): path = "/usr/bin/kyt/database.db"
    x = sqlite3.connect(path)
    x.row_factory = sqlite3.Row
    return x

def valid(id):
    """
    Fungsi Validasi Admin SUPER LENGKAP
    Mengecek: Config, Var.txt, dan Database
    """
    check_id = str(id).strip()
    
    # 1. CEK DARI CONFIG.PY (OWNER UTAMA)
    # -----------------------------------
    try:
        owners = [x.strip() for x in str(config.OWNER_ID).split(',')]
        if check_id in owners:
            return "true"
    except: pass

    # 2. CEK DARI VAR.TXT (ADMIN VARIABLE GLOBAL)
    # -----------------------------------
    # Kita ambil variabel ADMIN yang sudah di-load di atas
    try:
        # Gunakan 'globals()' untuk mengakses variabel ADMIN yang di-load exec()
        if 'ADMIN' in globals():
            admins_txt = [x.strip() for x in str(globals()['ADMIN']).split(',')]
            if check_id in admins_txt:
                return "true"
    except: pass

    # 3. CEK DARI DATABASE (BACKUP TERAKHIR)
    # -----------------------------------
    conn = None
    try:
        conn = get_db()
        cursor = conn.execute("SELECT user_id FROM admin")
        all_admins = cursor.fetchall()
        
        # Buat list ID dari database
        admin_list_db = [str(row[0]).strip() for row in all_admins]
        
        if check_id in admin_list_db:
            return "true"
            
    except Exception as e:
        print(f"Error in valid(): {e}")
        
    finally:
        if conn: conn.close()
        
    # Jika tidak ditemukan di mana-mana
    return "false"

def convert_size(size_bytes):
    """Konversi bytes ke KB, MB, GB"""
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return "%s %s" % (s, size_name[i])