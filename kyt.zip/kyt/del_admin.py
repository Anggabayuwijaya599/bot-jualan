import sqlite3
import os

# --- KONFIGURASI ---
ID_HAPUS = "7319690771" 
DB_PATH = "/usr/bin/kyt/database.db"
# -------------------

print(f"📂 Membuka database di: {DB_PATH}")

if not os.path.exists(DB_PATH):
    print("❌ Error: File database tidak ditemukan!")
    exit()

try:
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # 1. Cek dulu apakah ID tersebut ada?
    c.execute("SELECT user_id FROM admin WHERE user_id = ?", (ID_HAPUS,))
    if c.fetchone() is None:
        print(f"⚠️ User ID {ID_HAPUS} TIDAK ditemukan di daftar admin.")
    else:
        # 2. Hapus Admin
        c.execute("DELETE FROM admin WHERE user_id = ?", (ID_HAPUS,))
        conn.commit()
        print(f"✅ SUKSES! User ID {ID_HAPUS} telah DIHAPUS dari admin.")

    # 3. Tampilkan Sisa Admin
    print("\n📋 DAFTAR ADMIN TERSISA:")
    c.execute("SELECT user_id FROM admin")
    all_admins = c.fetchall()
    if not all_admins:
        print("   (Tidak ada admin)")
    for idx, admin in enumerate(all_admins):
        print(f" {idx+1}. {admin[0]}")

    conn.close()

except Exception as e:
    print(f"❌ Error Database: {e}")