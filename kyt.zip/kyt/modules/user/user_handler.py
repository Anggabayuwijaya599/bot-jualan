from telethon.tl.custom import Button
import subprocess

# Fungsi untuk mengambil data User & Tombol
def get_user_view(chat_id, first_name, status_display, show_dashboard, is_real_admin, domain):
    # 1. Ambil Info Server (Biar start.py bersih, taruh subprocess disini atau di helper)
    try:
        sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
        ssh = subprocess.check_output(sh, shell=True).decode("ascii").strip()
        sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
        namaos = subprocess.check_output(sdss, shell=True).decode("ascii").strip().replace('"','')
        ipvps = f" curl -s ipv4.icanhazip.com"
        ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii").strip()
        citsy = f" cat /etc/xray/city"
        city = subprocess.check_output(citsy, shell=True).decode("ascii").strip()
    except:
        namaos = "Ubuntu"; city = "Unknown"; ipsaya = "127.0.0.1"

    # 2. Susun Pesan
    msg = f"""
<b>🌋 SINGGAH VPN STORE</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
👋 <b>Halo, {first_name}!</b>
<i>Selamat datang di Premium Management Panel.</i>

<b>💻 SERVER INFORMATION</b>
┌──────────────────────────────
│ <b>⚙️ OS System</b>   : <code>{namaos}</code>
│ <b>📍 Location</b>    : <code>{city}</code>
│ <b>📡 Public IP</b>   : <code>{ipsaya}</code>
│ <b>🌐 Domain</b>      : <code>{domain}</code>
└──────────────────────────────

<b>👤 USER INFORMATION</b>
┌──────────────────────────────
│ <b>🆔 Telegram ID</b> : <code>{chat_id}</code>
│ <b>🏷️ Access Role</b> : <code>{status_display}</code>
└──────────────────────────────
"""

    # 3. Susun Tombol
    btn_channel = Button.url("💬 OFFICIAL CHANNEL","https://t.me/SinggahPrem")
    btn_order = Button.url("🛒 ORDER SCRIPT","https://t.me/SinggahPrem")
    
    inline = []
    
    if show_dashboard:
        # Tombol ini trigger callback 'menu_dashboard'
        inline.append([Button.inline("⚡ OPEN DASHBOARD PANEL","menu_dashboard")])
        inline.append([btn_channel, btn_order])
        
        # Tombol Switch khusus Admin Asli
        if is_real_admin:
            inline.append([Button.inline("👁️ LIHAT TAMPILAN USER", "switch_guest")])
    else:
        # Tampilan Guest
        inline.append([btn_order])
        inline.append([btn_channel])
        
        # Tombol Balik khusus Admin Asli
        if is_real_admin:
            inline.append([Button.inline("🔙 KEMBALI KE ADMIN", "switch_admin")])
            
    return msg, inline