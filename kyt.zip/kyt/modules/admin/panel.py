# FILE: modules/admin/panel.py
from kyt import *
from telethon import events
from telethon.tl.custom import Button

# Handler untuk callback data='menu'
@bot.on(events.CallbackQuery(data=b'menu'))
async def dashboard_handler(event):
    sender = await event.get_sender()
    chat_id = str(sender.id)
    
    # Validasi Double (Untuk keamanan ekstra)
    # Pastikan yang akses menu ini benar-benar admin/reseller yang valid
    if valid(chat_id) == "false":
        return await event.answer("❌ Akses Ditolak!", alert=True)

    # --- ISI MENU DASHBOARD ADMIN ---
    msg_panel = """
<b>⚡ ADMINISTRATOR DASHBOARD</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Silakan pilih menu manajemen server di bawah ini:
"""
    
    # Contoh Tombol Panel Admin
    buttons_panel = [
        [Button.inline("Create SSH", "addssh"), Button.inline("Create VMess", "addvmess")],
        [Button.inline("Cek User Login", "cekuser"), Button.inline("Reboot Server", "reboot")],
        [Button.inline("🔙 BACK TO HOME", "start")] # Tombol ini akan kembali ke start.py
    ]

    await event.edit(msg_panel, buttons=buttons_panel, parse_mode='html')

# Contoh Handler Dummy untuk tombol Create SSH (Opsional)
@bot.on(events.CallbackQuery(data=b'addssh'))
async def addssh_handler(event):
    await event.answer("Fitur Create SSH sedang dikembangkan...", alert=True)