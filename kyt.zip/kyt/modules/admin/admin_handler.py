from telethon.tl.custom import Button

def get_admin_panel():
    msg = """
<b>⚡ ADMINISTRATOR DASHBOARD</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Silakan pilih menu manajemen server di bawah ini:
"""
    
    buttons = [
        [Button.inline("Create SSH", "addssh"), Button.inline("Create VMess", "addvmess")],
        [Button.inline("Cek User Login", "cekuser"), Button.inline("Reboot Server", "reboot")],
        # Tombol ini trigger callback 'back_to_start' agar kembali ke tampilan awal
        [Button.inline("🔙 BACK TO HOME", "back_to_start")]
    ]
    
    return msg, buttons