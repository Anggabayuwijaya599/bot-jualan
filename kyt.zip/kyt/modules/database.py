# FILE: /usr/bin/kyt/modules/database.py

import sqlite3
import datetime
import random
import string

# Lokasi file database
DB_NAME = "/usr/bin/kyt/database.db"

def get_connection():
    return sqlite3.connect(DB_NAME, check_same_thread=False)

def init_db():
    """Membuat tabel jika belum ada"""
    conn = get_connection()
    c = conn.cursor()
    
    # 1. Tabel Users (Data Pengguna & Saldo)
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            saldo INTEGER DEFAULT 0,
            joined_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 2. Tabel Transactions (Riwayat)
    c.execute('''
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            trx_id TEXT,
            user_id INTEGER,
            type TEXT, 
            amount INTEGER,
            status TEXT,
            description TEXT,
            date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    # type: 'TOPUP', 'ORDER', 'REFUND'
    # status: 'PENDING', 'SUCCESS', 'FAILED'
    
    conn.commit()
    conn.close()

# ==========================================
# FUNGSI USER & SALDO
# ==========================================

def cek_user(user_id, username):
    """Mendaftarkan user baru atau update username jika sudah ada"""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
    data = c.fetchone()
    
    if data is None:
        # User Baru
        c.execute("INSERT INTO users (user_id, username, saldo) VALUES (?, ?, 0)", (user_id, username))
    else:
        # Update Username (siapa tau ganti)
        c.execute("UPDATE users SET username = ? WHERE user_id = ?", (username, user_id))
    
    conn.commit()
    conn.close()

def get_saldo(user_id):
    """Mengambil jumlah saldo user"""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT saldo FROM users WHERE user_id = ?", (user_id,))
    data = c.fetchone()
    conn.close()
    return data[0] if data else 0

def tambah_saldo(user_id, jumlah, sumber="Manual"):
    """Menambah saldo (Topup/Refund)"""
    conn = get_connection()
    c = conn.cursor()
    
    # Update Saldo
    c.execute("UPDATE users SET saldo = saldo + ? WHERE user_id = ?", (jumlah, user_id))
    
    # Catat Riwayat
    trx_id = f"TRX-{random.randint(10000,99999)}"
    c.execute('''INSERT INTO transactions (trx_id, user_id, type, amount, status, description) 
                 VALUES (?, ?, 'TOPUP', ?, 'SUCCESS', ?)''', 
                 (trx_id, user_id, jumlah, f"Deposit via {sumber}"))
    
    conn.commit()
    conn.close()
    return True

def kurang_saldo(user_id, jumlah, produk_nama):
    """Mengurangi saldo (Beli Produk)"""
    conn = get_connection()
    c = conn.cursor()
    
    # Cek saldo dulu
    c.execute("SELECT saldo FROM users WHERE user_id = ?", (user_id,))
    result = c.fetchone()
    current_saldo = result[0] if result else 0
    
    if current_saldo >= jumlah:
        # Potong Saldo
        c.execute("UPDATE users SET saldo = saldo - ? WHERE user_id = ?", (jumlah, user_id))
        
        # Catat Riwayat
        trx_id = f"ORD-{random.randint(10000,99999)}"
        c.execute('''INSERT INTO transactions (trx_id, user_id, type, amount, status, description) 
                     VALUES (?, ?, 'ORDER', ?, 'SUCCESS', ?)''', 
                     (trx_id, user_id, jumlah, f"Beli {produk_nama}"))
        
        conn.commit()
        conn.close()
        return True # Sukses
    else:
        conn.close()
        return False # Gagal (Saldo kurang)

# ==========================================
# FUNGSI RIWAYAT
# ==========================================

def get_riwayat(user_id, limit=5):
    """Mengambil 5 transaksi terakhir"""
    conn = get_connection()
    c = conn.cursor()
    c.execute('''SELECT trx_id, type, amount, status, date, description 
                 FROM transactions WHERE user_id = ? 
                 ORDER BY id DESC LIMIT ?''', (user_id, limit))
    data = c.fetchall()
    conn.close()
    return data
    
# TAMBAHKAN DI BAWAH FUNGSI TRANSAKSI YANG SUDAH ADA

def new_deposit(user_id, reff_id, amount, provider_id, metode, status="PENDING"):
    """Mencatat request deposit baru ke database"""
    conn = get_connection()
    c = conn.cursor()
    
    # Simpan ke tabel transactions
    # Kita simpan provider_id (ID dari Atlantic) di kolom description sementara atau buat kolom baru
    # Agar simpel, kita taruh detail di description
    desc = f"Deposit {metode} (Menunggu Pembayaran)"
    
    c.execute('''INSERT INTO transactions (trx_id, user_id, type, amount, status, description, date) 
                 VALUES (?, ?, 'DEPOSIT', ?, ?, ?, CURRENT_TIMESTAMP)''', 
                 (reff_id, user_id, amount, status, desc))
    
    conn.commit()
    conn.close()

def update_deposit_status(reff_id, status, keterangan=""):
    """Update status jika sudah bayar (Nanti dipakai saat pengecekan)"""
    conn = get_connection()
    c = conn.cursor()
    c.execute("UPDATE transactions SET status = ?, description = ? WHERE trx_id = ?", 
              (status, keterangan, reff_id))
    conn.commit()
    conn.close()
    
def get_trx_status(reff_id):
    """Mengambil status transaksi terakhir dari database"""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT status, amount FROM transactions WHERE trx_id = ?", (reff_id,))
    data = c.fetchone()
    conn.close()
    return data if data else (None, 0)

def update_trx_success(reff_id):
    """Update status jadi SUCCESS (Hanya status, saldo nambah terpisah)"""
    conn = get_connection()
    c = conn.cursor()
    c.execute("UPDATE transactions SET status = 'SUCCESS', description = 'Deposit Berhasil' WHERE trx_id = ?", (reff_id,))
    conn.commit()
    conn.close()
    
def get_trx_status(reff_id):
    """Mengambil status transaksi terakhir dari database"""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT status, amount FROM transactions WHERE trx_id = ?", (reff_id,))
    data = c.fetchone()
    conn.close()
    return data if data else (None, 0)

def update_trx_success(reff_id):
    """Update status jadi SUCCESS"""
    conn = get_connection()
    c = conn.cursor()
    c.execute("UPDATE transactions SET status = 'SUCCESS', description = 'Deposit Berhasil' WHERE trx_id = ?", (reff_id,))
    conn.commit()
    conn.close()

# --- TAMBAHAN BARU: GET ALL USERS ---
def get_all_users(limit=20):
    """Mengambil daftar user untuk Admin (Urut berdasarkan saldo terbanyak)"""
    conn = get_connection()
    c = conn.cursor()
    # Ambil user_id, username, saldo. Diurutkan saldo terbesar.
    c.execute("SELECT user_id, username, saldo FROM users ORDER BY saldo DESC LIMIT ?", (limit,))
    data = c.fetchall()
    conn.close()
    return data