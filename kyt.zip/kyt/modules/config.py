# FILE: /usr/bin/kyt/modules/config.py

# =================================================================
# 🔐 CONFIGURATION FILE
# Simpan semua data sensitif di sini. Jangan disebar!
# =================================================================

# 1. TELEGRAM ADMIN CONFIG
# ID Telegram Owner (Angka) - Ganti dengan ID Anda
OWNER_ID = "5572130876,7319690771"

# 2. RAMA SHOP H2H API KEY
RAMASHOP_KEY = "rg_8d6dee5af0ffc75ee66900820d9f79"

# 3. GLOBAL DOMAIN (Opsional, jika ingin setting manual)
# Jika dikosongkan, script akan mencoba deteksi otomatis atau pakai default
DOMAIN_MANUAL = "misnansg1.singgahvpn.web.id"
