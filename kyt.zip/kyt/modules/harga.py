# FILE: /usr/bin/kyt/modules/harga.py

# Format Konfigurasi:
# "kode_unik": {
#     "service": "Jenis Layanan (SSH/VMESS/dll)",
#     "nama": "Nama Tampilan di Menu",
#     "harga": Harga (Angka tanpa titik),
#     "durasi": Durasi Hari (Angka),
#     "iplimit": Limit IP (Angka)
# }

# FORMAT DAFTAR PRODUK
# Kode Produk (SSH1, VMESS1, dll) harus unik.
# service: Harus SESUAI dengan kategori di menu (SSH, VMESS, VLESS, TROJAN, SHADOWSOCKS)

daftar_produk = {
    # ==============================
    # KATEGORI SSH (PILIHAN SERVER)
    # ==============================
    "SSH_INDO": {
        "nama": "🇮🇩 SSH 30 Hari (Server INDO)",
        "harga": 7000,
        "service": "SSH",
        "exp": 30, "limit": 2, "quota": 0
    },
    "SSH_SG1": {
        "nama": "🇸🇬 SSH 30 Hari (Server SG 1)",
        "harga": 7000,
        "service": "SSH",
        "exp": 30, "limit": 2, "quota": 0
    },
    "SSH_SG2": {
        "nama": "🇸🇬 SSH 30 Hari (Server SG 2)",
        "harga": 7000,
        "service": "SSH",
        "exp": 30, "limit": 2, "quota": 0
    },
    "SSH_SG3": {
        "nama": "🇸🇬 SSH 30 Hari (Server SG 3)",
        "harga": 7000,
        "service": "SSH",
        "exp": 30, "limit": 2, "quota": 0
    },

    # ==============================
    # KATEGORI VMESS
    # ==============================
    "VMESS_INDO": {
        "nama": "⚡ VMESS 30 Hari (Server INDO)",
        "harga": 7000, "service": "VMESS", "exp": 30, "limit": 2, "quota": 0
    },
    "VMESS_SG1": {
        "nama": "⚡ VMESS 30 Hari (Server SG 1)",
        "harga": 7000, "service": "VMESS", "exp": 30, "limit": 2, "quota": 0
    },
    "VMESS_SG2": {
        "nama": "⚡ VMESS 30 Hari (Server SG 2)",
        "harga": 7000, "service": "VMESS", "exp": 30, "limit": 2, "quota": 0
    },
    "VMESS_SG3": {
        "nama": "⚡ VMESS 30 Hari (Server SG 3)",
        "harga": 7000, "service": "VMESS", "exp": 30, "limit": 2, "quota": 0
    },
    # ==============================
    # KATEGORI VLESS
    # ==============================
    "VLESS_INDO": {
        "nama": "🚀 VLESS 30 Hari (Server INDO)",
        "harga": 7000, "service": "VLESS", "exp": 30, "limit": 2, "quota": 0
    },
    "VLESS_SG1": {
        "nama": "🚀 VLESS 30 Hari (Server SG 1)",
        "harga": 7000, "service": "VLESS", "exp": 30, "limit": 2, "quota": 0
    },
    "VLESS_SG2": {
        "nama": "🚀 VLESS 30 Hari (Server SG 2)",
        "harga": 7000, "service": "VLESS", "exp": 30, "limit": 2, "quota": 0
    },
    "VLESS_SG3": {
        "nama": "🚀 VLESS 30 Hari (Server SG 3)",
        "harga": 7000, "service": "VLESS", "exp": 30, "limit": 2, "quota": 0
    },
    # ==============================
    # KATEGORI TROJAN
    # ==============================
    "TROJAN_INDO": {
        "nama": "🛡️ TROJAN 30 Hari (Server INDO)",
        "harga": 7000, "service": "TROJAN", "exp": 30, "limit": 2, "quota": 0
    },
    "TROJAN_SG1": {
        "nama": "🛡️ TROJAN 30 Hari (Server SG 1)",
        "harga": 7000, "service": "TROJAN", "exp": 30, "limit": 2, "quota": 0
    },
    "TROJAN_SG2": {
        "nama": "🛡️ TROJAN 30 Hari (Server SG 2)",
        "harga": 7000, "service": "TROJAN", "exp": 30, "limit": 2, "quota": 0
    },
    "TROJAN_SG3": {
        "nama": "🛡️ TROJAN 30 Hari (Server SG 3)",
        "harga": 7000, "service": "TROJAN", "exp": 30, "limit": 2, "quota": 0
    },
    "SS1": {
        "nama": "👻 Shadowsocks 30 Hari",
        "harga": 7000, "service": "SHADOWSOCKS", "exp": 30, "limit": 2, "quota": 0
    }
}

# Fungsi Helper untuk memformat Rupiah
def format_rupiah(angka):
    return f"Rp {angka:,}".replace(",", ".")