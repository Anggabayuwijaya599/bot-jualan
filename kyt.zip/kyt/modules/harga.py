# FILE: /usr/bin/kyt/modules/harga.py

# Format Konfigurasi:
# "kode_unik": {
#     "service": "Jenis Layanan (SSH/VMESS/dll)",
#     "nama": "Nama Tampilan di Menu",
#     "harga": Harga (Angka tanpa titik),
#     "durasi": Durasi Hari (Angka),
#     "iplimit": Limit IP (Angka)
# }

# FORMAT DAFTAR PRODUK
# Kode Produk (SSH1, VMESS1, dll) harus unik.
# service: Harus SESUAI dengan kategori di menu (SSH, VMESS, VLESS, TROJAN, SHADOWSOCKS)

daftar_produk = {
    # ==============================
    # KATEGORI SSH
    # ==============================
    "SSH1": {
        "nama": "☁️ SSH Premium 30 Hari",
        "harga": 7000,
        "service": "SSH",
        "exp": 30,      # Masa aktif (hari)
        "limit": 2,     # Limit Login/IP
        "quota": 0      # 0 = Unlimited
    },

    # ==============================
    # KATEGORI VMESS (SUDAH DIUBAH)
    # ==============================
    "VMESS1": {
        "nama": "⚡ VMess Premium 30 Hari",
        "harga": 7000,  # Harga disamakan Rp 7.000
        "service": "VMESS",
        "exp": 30,
        "limit": 2,
        "quota": 0
    },
    # Paket 60 hari sudah dihapus dari sini

    # ==============================
    # KATEGORI VLESS
    # ==============================
    "VLESS1": {
        "nama": "🚀 VLess Premium 30 Hari",
        "harga": 7000,
        "service": "VLESS",
        "exp": 30,
        "limit": 2,
        "quota": 0
    },

    # ==============================
    # KATEGORI TROJAN
    # ==============================
    "TROJAN1": {
        "nama": "🛡 Trojan Premium 30 Hari",
        "harga": 7000,
        "service": "TROJAN",
        "exp": 30,
        "limit": 2,
        "quota": 0
    },

    # ==============================
    # KATEGORI SHADOWSOCKS
    # ==============================
    "SS1": {
        "nama": "👻 Shadowsocks 30 Hari",
        "harga": 7000,
        "service": "SHADOWSOCKS",
        "exp": 30,
        "limit": 2,
        "quota": 0
    }
}

def format_rupiah(nominal):
    return f"Rp {nominal:,}".replace(",", ".")

# Fungsi Helper untuk memformat Rupiah
def format_rupiah(angka):
    return f"Rp {angka:,}".replace(",", ".")