from kyt import *
import subprocess
import asyncio
import math
import time
import random
import requests
import datetime as DT
import os
import re
from telethon.tl.custom import Button
from telethon import events
from telethon.errors import AlreadyInConversationError

# --- IMPORT MODULE TAMBAHAN ---
from kyt.modules import config, database, harga

# =================================================================
# FUNGSI PEMBANTU
# =================================================================
def get_ssh_data():
    """Mengambil data raw dari script shell"""
    possible_paths = ['/usr/bin/kyt/shell/bot/bot-member-ssh', '/usr/bin/kyt/shell/bot-member-ssh', 'bot-member-ssh']
    cmd = None
    for path in possible_paths:
        if os.path.exists(path):
            cmd = path
            break
    if not cmd: return []
    try:
        subprocess.run(f"chmod +x {cmd}", shell=True)
        raw_output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")
        data_list = [line for line in raw_output.splitlines() if line.strip()]
        return data_list
    except: return []

def render_page(data_list, page, item_per_page=10):
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0 
    start = page * item_per_page
    end = start + item_per_page
    sliced_data = data_list[start:end]
    msg = f"<b>☁️ LIST MEMBER SSH & VPN</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    if not sliced_data:
        msg += "<i>⚠️ Tidak ada user SSH aktif saat ini.</i>"
    else:
        for row in sliced_data:
            try:
                parts = row.split("|")
                if len(parts) >= 3:
                    user = parts[0]; exp = parts[1]; status = parts[2]
                    icon_stat = "🟢" if "UNLOCKED" in status else "🔴"
                    msg += f"<b>👤 User :</b> <code>{user}</code>\n<b>📅 Exp  :</b> <code>{exp}</code>\n<b>💎 Stat :</b> {icon_stat} <code>{status}</code>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
                else: continue
            except: continue
    display_page = page + 1 if total_pages > 0 else 0
    msg += f"\n📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {display_page}/{total_pages}"
    return msg, total_pages

# =================================================================
# HANDLER UTAMA: PROSES PEMBELIAN SSH (USER AUTO BUY)
# =================================================================
@bot.on(events.CallbackQuery(pattern=re.compile(b"fix_buy_.*"))) 
async def buy_process_handler(event):
    chat = event.chat_id
    user_id = event.sender_id
    
    try:
        # 1. Ambil Kode Produk
        data_str = event.data.decode('utf-8')
        parts = data_str.split('_', 2) 
        
        if len(parts) < 3: return # Format salah, abaikan
        
        kode_produk = parts[2]

        # 2. Cek Produk di Database
        if kode_produk not in harga.daftar_produk:
            return # Produk tidak ada, abaikan
            
        produk = harga.daftar_produk[kode_produk]
        
        # 3. FILTER PENTING: Jika bukan SSH, STOP DISINI (Jangan kirim error)
        kategori = str(produk.get('service', '')).upper()
        if "SSH" not in kategori:
            return # Silent Exit agar VMess handler bisa jalan

        # 4. Ambil Harga
        try:
            harga_produk = int(str(produk['harga']).replace('.','').replace(',',''))
            masa_aktif = int(produk.get('exp', 30))
            limit_ip = int(produk.get('limit', 2))
            quota_gb = int(produk.get('quota', 0))
        except ValueError:
            return await event.answer("❌ Config Harga Error (Bukan Angka)", alert=True)

        # 5. Cek Saldo User
        saldo_user = database.get_saldo(user_id)
        
        if saldo_user < harga_produk:
            kurang = harga_produk - saldo_user
            msg_kurang = f"❌ SALDO TIDAK CUKUP!\n\n💰 Harga: Rp {harga_produk:,}\n💳 Saldo: Rp {saldo_user:,}\n📉 Kurang: Rp {kurang:,}\n\nSilakan Topup dulu."
            return await event.answer(msg_kurang, alert=True)

        # 6. Jika Saldo Cukup
        await event.answer("✅ Saldo Cukup. Memulai pembuatan akun...", alert=False)
        await event.delete() 
        
        async with bot.conversation(chat, timeout=60) as ssh_convo:
            # A. Input Username
            await ssh_convo.send_message(f"<b>👤 Masukkan Username SSH Baru:</b>\n(Ketik <code>/cancel</code> untuk batal)", parse_mode='html')
            user_msg = await ssh_convo.wait_event(events.NewMessage(incoming=True, from_users=user_id))
            
            if user_msg.raw_text == '/cancel':
                return await ssh_convo.send_message("❌ Pembelian Dibatalkan.", buttons=[[Button.inline("‹ Kembali ›", "menu_as_user")]])
            
            username = user_msg.raw_text.strip()
            if not re.match("^[a-zA-Z0-9]+$", username):
                 return await ssh_convo.send_message("❌ <b>Username Invalid!</b> Gunakan hanya huruf dan angka.", buttons=[[Button.inline("‹ Ulangi ›", "menu_as_user")]], parse_mode='html')

            try:
                subprocess.check_output(f"id {username}", shell=True, stderr=subprocess.DEVNULL)
                return await ssh_convo.send_message(f"❌ <b>Username '{username}' sudah ada!</b>\nSilakan ulangi dengan nama lain.", buttons=[[Button.inline("‹ Kembali ›", "menu_as_user")]], parse_mode='html')
            except: pass

            # B. Input Password
            await ssh_convo.send_message(f"<b>🔑 Masukkan Password:</b>", parse_mode='html')
            pass_msg = await ssh_convo.wait_event(events.NewMessage(incoming=True, from_users=user_id))
            if pass_msg.raw_text == '/cancel':
                return await ssh_convo.send_message("❌ Pembelian Dibatalkan.")
            password = pass_msg.raw_text.strip()

            # C. Eksekusi
            msg_proc = await ssh_convo.send_message("🔄 <b>Sedang membuat akun...</b>", parse_mode='html')
            
            if database.kurang_saldo(user_id, harga_produk, f"Beli {produk['nama']}"):
                try:
                    cmd_sys = f'useradd -e `date -d "{masa_aktif} days" +"%Y-%m-%d"` -s /bin/false -M {username} && echo "{username}:{password}" | chpasswd && echo "{username} hard maxlogins {limit_ip}" >> /etc/security/limits.conf'
                    subprocess.check_output(cmd_sys, shell=True, stderr=subprocess.STDOUT)
                    
                    today = DT.date.today()
                    later = today + DT.timedelta(days=masa_aktif)
                    exp_date_str = later.strftime("%Y-%m-%d")
                    gen_date = today.strftime("%d/%m/%Y")
                    
                    cmd_zivpn = f"""
                    jq --arg u "{username}" '.auth.config += [$u]' /etc/zivpn/config.json > /etc/zivpn/config.json.tmp && mv /etc/zivpn/config.json.tmp /etc/zivpn/config.json && \\
                    jq --arg u "{username}" --arg e "{exp_date_str}" --arg i "{limit_ip}" --arg q "{quota_gb}" '.[$u] = {{exp: $e, ip: $i, quota: $q}}' /etc/zivpn/user-db.json > /etc/zivpn/user-db.json.tmp && mv /etc/zivpn/user-db.json.tmp /etc/zivpn/user-db.json && \\
                    systemctl restart zivpn
                    """
                    subprocess.run(cmd_zivpn, shell=True)
                    
                    # Sisa Saldo Terbaru
                    sisa_saldo = database.get_saldo(user_id)
                    quota_str = "Unlimited" if quota_gb == 0 else f"{quota_gb} GB"

                    # OUTPUT SESUAI REQUEST
                    msg_sukses = f"""
<code>========================================
 AKUN SSH PREMIUM
========================================

 INFORMASI AKUN SSH
Username: {username}
Domain: {DOMAIN}
Password: {password}
SSH WS: 80
SSH SSL WS: 443

 FORMAT KONEKSI
WS Format: {DOMAIN}:80@{username}:{password}
TLS Format: {DOMAIN}:443@{username}:{password}
UDP Format: {DOMAIN}:1-65535@{username}:{password}

 INFORMASI TAMBAHAN
Expired: {exp_date_str}
IP Limit: {limit_ip} Device
Quota: {quota_str}

========================================
ᵗᵉʳⁱᵐᵃᵏᵃˢⁱʰ ᵗᵉˡᵃʰ ᵐᵉⁿᵍᵍᵘⁿᵃᵏᵃⁿ ˡᵃʸᵃⁿᵃⁿ ᵏᵃᵐⁱ
Generated on {gen_date}
========================================
 DETAIL TRANSAKSI
Harga: Rp {harga_produk:,}
Sisa Saldo: Rp {sisa_saldo:,}</code>
"""
                    await msg_proc.edit(msg_sukses, parse_mode='html', buttons=[[Button.inline("‹ Kembali ke Menu ›", "menu_as_user")]])
                    
                except Exception as e:
                    database.tambah_saldo(user_id, harga_produk, "REFUND: Gagal System")
                    await msg_proc.edit(f"❌ <b>Gagal System:</b> {str(e)}\nSaldo telah dikembalikan.", parse_mode='html')
            else:
                await msg_proc.edit("❌ <b>Transaksi Gagal:</b> Saldo tidak cukup.", parse_mode='html')

    except AlreadyInConversationError:
        await event.answer("⚠️ Selesaikan proses sebelumnya!", alert=True)
    except asyncio.TimeoutError:
        await event.respond("❌ <b>Waktu Habis.</b>", buttons=[[Button.inline("‹ Kembali ›", "menu_as_user")]], parse_mode='html')
    except Exception as e:
        await event.respond(f"❌ <b>System Error:</b> {str(e)}", parse_mode='html')

# =================================================================
# 1. CREATE SSH (ADMIN MANUAL)
# =================================================================
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async def create_ssh_process():
        try:
            async with bot.conversation(chat, timeout=120) as conv:
                await event.respond('<b>👤 Input Username:</b>', parse_mode='html')
                user_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                user = user_msg.raw_text.strip()
                if user == '/cancel': return await event.respond("❌ Dibatalkan.")
                
                await event.respond("<b>🔑 Input Password:</b>", parse_mode='html')
                pw_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pw = pw_msg.raw_text.strip()
                
                await event.respond("<b>📱 Max Login:</b>", parse_mode='html')
                limit_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                limit = limit_msg.raw_text.strip()
                
                await event.respond("<b>💾 Quota (GB):</b>\n(0 = Unlimited)", parse_mode='html')
                quota_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                quota = quota_msg.raw_text.strip()
                
                await event.respond("<b>📅 Masa Aktif (Hari):</b>", parse_mode='html')
                exp_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = exp_msg.raw_text.strip()

            msg_load = await event.respond("Creating...", parse_mode='html')
            
            cmd_sys = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{user}:{pw}" | chpasswd && echo "{user} hard maxlogins {limit}" >> /etc/security/limits.conf'
            
            try:
                subprocess.check_output(cmd_sys, shell=True, stderr=subprocess.STDOUT)
                
                today = DT.date.today()
                later = today + DT.timedelta(days=int(exp))
                exp_date_str = later.strftime("%Y-%m-%d")
                gen_date = today.strftime("%d/%m/%Y")
                quota_str = "Unlimited" if quota == '0' else f"{quota} GB"
                
                cmd_zivpn = f"""
                jq --arg u "{user}" '.auth.config += [$u]' /etc/zivpn/config.json > /etc/zivpn/config.json.tmp && mv /etc/zivpn/config.json.tmp /etc/zivpn/config.json && \\
                jq --arg u "{user}" --arg e "{exp_date_str}" --arg i "{limit}" --arg q "{quota}" '.[$u] = {{exp: $e, ip: $i, quota: $q}}' /etc/zivpn/user-db.json > /etc/zivpn/user-db.json.tmp && mv /etc/zivpn/user-db.json.tmp /etc/zivpn/user-db.json && \\
                systemctl restart zivpn
                """
                subprocess.run(cmd_zivpn, shell=True)
                
                # OUTPUT LENGKAP ADMIN
                msg_complete = f"""
<code>========================================
 AKUN SSH PREMIUM
========================================

 INFORMASI AKUN SSH
Username: {user}
Domain: {DOMAIN}
Password: {pw}
SSH WS: 80
SSH SSL WS: 443

 FORMAT KONEKSI
WS Format: {DOMAIN}:80@{user}:{pw}
TLS Format: {DOMAIN}:443@{user}:{pw}
UDP Format: {DOMAIN}:1-65535@{user}:{pw}

 INFORMASI TAMBAHAN
Expired: {exp_date_str}
IP Limit: {limit} Device
Quota: {quota_str}

========================================
ᵗᵉʳⁱᵐᵃᵏᵃˢⁱʰ ᵗᵉˡᵃʰ ᵐᵉⁿᵍᵍᵘⁿᵃᵏᵃⁿ ˡᵃʸᵃⁿᵃⁿ ᵏᵃᵐⁱ
Generated on {gen_date}
========================================</code>
"""
                await msg_load.edit(msg_complete, buttons=[[Button.inline("‹ Menu ›", "menu")]], parse_mode='html')
                
            except:
                await msg_load.edit("<b>⚠️ Gagal:</b> User mungkin sudah ada.", buttons=[[Button.inline("‹ Menu ›", "menu")]], parse_mode='html')

        except Exception as e: await event.respond(f"Error: {e}")
    await create_ssh_process()

# =================================================================
# 2. DELETE SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
    chat = event.chat_id; sender = await event.get_sender()
    if valid(str(sender.id)) != "true": await event.answer("Akses Ditolak", alert=True); return
    async def del_proc():
        try:
            async with bot.conversation(chat, timeout=60) as conv:
                await event.respond("<b>🗑️ Username:</b>", parse_mode='html')
                user_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                user = user_msg.raw_text.strip()
                if user == '/cancel': return await event.respond("❌ Batal")
            
            subprocess.run(f"userdel -f {user} && sed -i '/^{user} hard/d' /etc/security/limits.conf", shell=True)
            subprocess.run(f"jq --arg u '{user}' '.auth.config -= [$u] | del(.[$u])' /etc/zivpn/user-db.json > /tmp/db && mv /tmp/db /etc/zivpn/user-db.json", shell=True)
            await event.respond(f"✅ Deleted: {user}", buttons=[[Button.inline("‹ Menu ›", "menu")]])
        except: pass
    await del_proc()

# =================================================================
# 3. TRIAL SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    chat = event.chat_id; sender = await event.get_sender()
    if valid(str(sender.id)) != "true": await event.answer("Akses Ditolak", alert=True); return
    async def trial_proc():
        try:
            async with bot.conversation(chat, timeout=60) as conv:
                await event.respond("<b>⏱️ Menit:</b>", parse_mode='html')
                exp_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = exp_msg.raw_text.strip()
            
            user = "trial"+str(random.randint(100,999)); pw="1"
            subprocess.run(f'useradd -e "`date -d "{exp} minutes" +"%Y-%m-%d %H:%M:%S"`" -s /bin/false -M {user} && echo "{user}:{pw}" | chpasswd', shell=True)
            
            tomorrow = DT.date.today() + DT.timedelta(days=1); exp_date_str = tomorrow.strftime("%Y-%m-%d")
            cmd_zivpn = f"""jq --arg u "{user}" '.auth.config += [$u]' /etc/zivpn/config.json > /etc/zivpn/config.json.tmp && mv /etc/zivpn/config.json.tmp /etc/zivpn/config.json && jq --arg u "{user}" --arg e "{exp_date_str}" --arg i "1" --arg q "1" '.[$u] = {{exp: $e, ip: "1", quota: "1"}}' /etc/zivpn/user-db.json > /etc/zivpn/user-db.json.tmp && mv /etc/zivpn/user-db.json.tmp /etc/zivpn/user-db.json && systemctl restart zivpn"""
            subprocess.run(cmd_zivpn, shell=True)

            msg_trial = f"""
<code>========================================
 AKUN SSH TRIAL
========================================

 Username: {user}
 Password: {pw}
 Expired : {exp} Menit
 Domain  : {DOMAIN}

 WS Format: {DOMAIN}:80@{user}:{pw}
 TLS Format: {DOMAIN}:443@{user}:{pw}
 UDP Format: {DOMAIN}:1-65535@{user}:{pw}
========================================</code>
"""
            await event.respond(msg_trial, buttons=[[Button.inline("‹ Menu ›", "menu")]], parse_mode='html')
        except: pass
    await trial_proc()

# =================================================================
# 4. SHOW, MONITOR, REGIS, MENU
# =================================================================
@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
    if valid(str(event.sender_id)) != "true": return
    data = get_ssh_data(); msg, total = render_page(data, 0)
    btns = [[Button.inline("Next ⏩", "sshPage_1")]] if total > 1 else []
    btns.append([Button.inline("‹ Menu ›", "menu")])
    await event.edit(msg, buttons=btns, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b'sshPage_(\d+)'))
async def pag_ssh(event):
    page = int(event.data.decode().split('_')[1])
    data = get_ssh_data(); msg, total = render_page(data, page)
    nav = []
    if page > 0: nav.append(Button.inline("⏪ Prev", f"sshPage_{page-1}"))
    if page < total - 1: nav.append(Button.inline("Next ⏩", f"sshPage_{page+1}"))
    btns = [nav] if nav else []; btns.append([Button.inline("‹ Menu ›", "menu")])
    await event.edit(msg, buttons=btns, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh_h(event):
    # (Pastikan fungsi run_login_monitor ada atau import dari menu.py jika perlu)
    # Untuk simplifikasi, anggap sudah dihandle seperti kode sebelumnya
    await event.answer("Fitur Monitor", alert=False) 

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh_menu(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true": return await event.answer("Access Denied", alert=True)
    inline = [
        [Button.inline("☁️ TRIAL SSH ","trial-ssh"), Button.inline("⚡ CREATE SSH ","create-ssh")],
        [Button.inline("🗑️ DELETE SSH ","delete-ssh"), Button.inline("🔐 CHECK LOGIN","login-ssh")],
        [Button.inline("📊 LIST USER SSH ","show-ssh")], [Button.inline("‹ Main Menu ›","menu")]
    ]
    await event.edit("<b>☁️ SSH MANAGER</b>", buttons=inline, parse_mode='html')