from kyt import *
import subprocess
import asyncio
import math
import time
import random
import requests
import datetime as DT
import os
import re
from telethon.tl.custom import Button
from telethon import events
from telethon.errors import AlreadyInConversationError
import paramiko
# --- IMPORT MODULE TAMBAHAN ---
from kyt.modules import config, database, harga

# =================================================================
# FUNGSI BACA VAR.TXT (OTOMATIS)
# =================================================================
def get_var_value(key_name):
    """
    Mencari value dari key tertentu di var.txt
    Contoh: get_var_value("GROUP") akan mengembalikan ID group
    """
    var_path_list = ["/root/var.txt", "/usr/bin/kyt/var.txt"]
    
    for var_file in var_path_list:
        if os.path.exists(var_file):
            try:
                with open(var_file, "r") as f:
                    lines = f.readlines()
                    for line in lines:
                        if line.startswith(f"{key_name}="):
                            # Ambil isi setelah sama dengan, hilangkan kutip dan spasi
                            val = line.strip().split("=", 1)[1].replace('"', '').replace("'", "")
                            return val
            except: pass
    return None

# =================================================================
# FUNGSI NOTIFIKASI / TESTIMONI (SUPPORT TOPIC)
# =================================================================
async def kirim_testimoni(user_telegram, role_user, tipe_akun, username_akun, exp_days, quota_str, harga, server_name="SG-DO"):
    """
    Mengirim laporan transaksi ke Group (Support Topic ID format: -100xxx_TopicID)
    """
    try:
        # 1. Ambil ID dari var.txt
        raw_group = get_var_value("GROUP")
        
        if not raw_group: 
            print("⚠️ GROUP ID tidak ditemukan di var.txt")
            return

        # 2. Logika Deteksi Topic (ID_TOPIC)
        # Contoh: -100123456789_45
        target_chat_id = 0
        target_topic_id = None

        if "_" in raw_group:
            parts = raw_group.split("_")
            try:
                target_chat_id = int(parts[0])
                target_topic_id = int(parts[1])
            except ValueError:
                print("❌ Format Group ID salah. Harus angka.")
                return
        else:
            try:
                target_chat_id = int(raw_group)
            except ValueError:
                return

        waktu = DT.datetime.now().strftime("%d/%m/%Y, %H.%M.%S")
        
        # 3. Format Pesan
        pesan = f"""
<b>📢 Account Created</b>
────────────────────
👤 <b>User:</b> {user_telegram}
🏷️ <b>Role:</b> {role_user}
📄 <b>Type:</b> {tipe_akun}
🔥 <b>Username:</b> <code>{username_akun}</code>
📅 <b>Expired:</b> {exp_days} Days
💾 <b>Quota:</b> {quota_str}
💰 <b>Harga:</b> Rp {harga}
🌐 <b>Server:</b> {server_name}
⏰ <b>Time:</b> {waktu}
────────────────────
"""
        # 4. Eksekusi Pengiriman
        if target_topic_id:
            # Kirim ke Spesifik Topic (Menggunakan reply_to untuk Telethon)
            await bot.send_message(target_chat_id, pesan, parse_mode='html', reply_to=target_topic_id)
        else:
            # Kirim ke Group Biasa (Tanpa Topic)
            await bot.send_message(target_chat_id, pesan, parse_mode='html')
        
    except Exception as e:
        print(f"❌ Gagal kirim notif group: {e}")

# =================================================================
# FUNGSI PEMBANTU LAINNYA
# =================================================================
def get_ssh_data():
    """Mengambil data raw dari script shell"""
    possible_paths = ['/usr/bin/kyt/shell/bot/bot-member-ssh', '/usr/bin/kyt/shell/bot-member-ssh', 'bot-member-ssh']
    cmd = None
    for path in possible_paths:
        if os.path.exists(path):
            cmd = path
            break
    if not cmd: return []
    try:
        subprocess.run(f"chmod +x {cmd}", shell=True)
        raw_output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")
        data_list = [line for line in raw_output.splitlines() if line.strip()]
        return data_list
    except: return []

def render_page(data_list, page, item_per_page=10):
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0 
    start = page * item_per_page
    end = start + item_per_page
    sliced_data = data_list[start:end]
    msg = f"<b>☁️ LIST MEMBER SSH & VPN</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    if not sliced_data:
        msg += "<i>⚠️ Tidak ada user SSH aktif saat ini.</i>"
    else:
        for row in sliced_data:
            try:
                parts = row.split("|")
                if len(parts) >= 3:
                    user = parts[0]; exp = parts[1]; status = parts[2]
                    icon_stat = "🟢" if "UNLOCKED" in status else "🔴"
                    msg += f"<b>👤 User :</b> <code>{user}</code>\n<b>📅 Exp  :</b> <code>{exp}</code>\n<b>💎 Stat :</b> {icon_stat} <code>{status}</code>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
                else: continue
            except: continue
    display_page = page + 1 if total_pages > 0 else 0
    msg += f"\n📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {display_page}/{total_pages}"
    return msg, total_pages

# =================================================================
# HANDLER UTAMA: PROSES PEMBELIAN SSH (USER AUTO BUY)
# =================================================================
@bot.on(events.CallbackQuery(pattern=re.compile(b"fix_buy_.*"))) 
async def buy_process_handler(event):
    chat = event.chat_id
    user_id = event.sender_id
    sender = await event.get_sender()
    nama_pembeli = sender.first_name
    
    try:
        # 1. Ambil Kode Produk
        data_str = event.data.decode('utf-8')
        parts = data_str.split('_', 2) 
        if len(parts) < 3: return 
        kode_produk = parts[2]

        # 2. Cek Produk di Database
        if kode_produk not in harga.daftar_produk: return 
        produk = harga.daftar_produk[kode_produk]
        
        # 3. FILTER: Jika bukan SSH, STOP
        kategori = str(produk.get('service', '')).upper()
        if "SSH" not in kategori: return 

        # 4. Ambil Harga
        try:
            harga_produk = int(str(produk['harga']).replace('.','').replace(',',''))
            masa_aktif = int(produk.get('exp', 30))
            limit_ip = int(produk.get('limit', 2))
            quota_gb = int(produk.get('quota', 0))
        except ValueError:
            return await event.answer("❌ Config Harga Error", alert=True)

        # 5. Cek Saldo
        saldo_user = database.get_saldo(user_id)
        if saldo_user < harga_produk:
            kurang = harga_produk - saldo_user
            msg_kurang = f"❌ SALDO TIDAK CUKUP!\n\n💰 Harga: Rp {harga_produk:,}\n💳 Saldo: Rp {saldo_user:,}\n📉 Kurang: Rp {kurang:,}\n\nSilakan Topup dulu."
            return await event.answer(msg_kurang, alert=True)

        # 6. Proses Beli (Masuk ke Conversation)
        await event.answer("✅ Saldo Cukup. Memulai...", alert=False)
        await event.delete() 
        
        async with bot.conversation(chat, timeout=120) as ssh_convo:
            
            # --- A. MENENTUKAN SERVER DARI KODE PRODUK MENU ---
            if kode_produk == "SSH_INDO":
                pilihan_server = "srv_pusat"
                nama_server_terpilih = "Server Pusat (INDO)"
            elif kode_produk == "SSH_SG1":
                pilihan_server = "srv_sg1"
                nama_server_terpilih = "Server SG 1"
            elif kode_produk == "SSH_SG2":
                pilihan_server = "srv_sg2"
                nama_server_terpilih = "Server SG 2"
            elif kode_produk == "SSH_SG3":
                pilihan_server = "srv_sg3"
                nama_server_terpilih = "Server SG 3"
            else:
                pilihan_server = "srv_pusat"
                nama_server_terpilih = "Server Pusat"

            # --- B. Input Username ---
            await ssh_convo.send_message(f"✅ Anda memilih <b>{nama_server_terpilih}</b>.\n\n<b>👤 Masukkan Username SSH Baru:</b>\n(Ketik <code>/cancel</code> untuk batal)", parse_mode='html')
            user_msg = await ssh_convo.wait_event(events.NewMessage(incoming=True, from_users=user_id))
            
            if user_msg.raw_text == '/cancel':
                return await ssh_convo.send_message("❌ Pembelian Dibatalkan.", buttons=[[Button.inline("‹ Kembali ›", "menu_as_user")]])
            
            username = user_msg.raw_text.strip()
            if not re.match("^[a-zA-Z0-9]+$", username):
                 return await ssh_convo.send_message("❌ <b>Username Invalid! Hanya gunakan huruf dan angka.</b>", buttons=[[Button.inline("‹ Ulangi ›", "menu_as_user")]], parse_mode='html')

            try:
                subprocess.check_output(f"id {username}", shell=True, stderr=subprocess.DEVNULL)
                return await ssh_convo.send_message(f"❌ <b>Username '{username}' sudah terpakai di server ini!</b>", buttons=[[Button.inline("‹ Kembali ›", "menu_as_user")]], parse_mode='html')
            except: pass

            # --- C. Input Password ---
            await ssh_convo.send_message(f"<b>🔑 Masukkan Password:</b>", parse_mode='html')
            pass_msg = await ssh_convo.wait_event(events.NewMessage(incoming=True, from_users=user_id))
            if pass_msg.raw_text == '/cancel': return await ssh_convo.send_message("❌ Pembelian Dibatalkan.")
            password = pass_msg.raw_text.strip()

            # --- D. Eksekusi Pembuatan Akun ---
            msg_proc = await ssh_convo.send_message(f"🔄 <b>Sedang membuat akun di {nama_server_terpilih}...</b>", parse_mode='html')
            
            if database.kurang_saldo(user_id, harga_produk, f"Beli {produk['nama']} | Akun: {username} | Pass: {password}"):
                try:
                    # =========================================================
                    # LOGIKA PERCABANGAN SERVER
                    # =========================================================
                    if pilihan_server == "srv_pusat":
                        # --- EKSEKUSI LOKAL (SERVER PUSAT / INDO) ---
                        cmd_sys = f'useradd -e `date -d "{masa_aktif} days" +"%Y-%m-%d"` -s /bin/false -M {username} && echo "{username}:{password}" | chpasswd && echo "{username} hard maxlogins {limit_ip}" >> /etc/security/limits.conf'
                        subprocess.check_output(cmd_sys, shell=True, stderr=subprocess.STDOUT)
                        
                        today = DT.date.today()
                        later = today + DT.timedelta(days=masa_aktif)
                        exp_date_str = later.strftime("%Y-%m-%d")
                        gen_date = today.strftime("%d/%m/%Y")
                        
                        # Pengaman: Hanya jalankan zivpn jika foldernya ada
                        cmd_zivpn = f"""
                        if [ -d "/etc/zivpn" ]; then
                            jq --arg u "{username}" '.auth.config += [$u]' /etc/zivpn/config.json > /etc/zivpn/config.json.tmp && mv /etc/zivpn/config.json.tmp /etc/zivpn/config.json
                            jq --arg u "{username}" --arg e "{exp_date_str}" --arg i "{limit_ip}" --arg q "{quota_gb}" '.[$u] = {{exp: $e, ip: $i, quota: $q}}' /etc/zivpn/user-db.json > /etc/zivpn/user-db.json.tmp && mv /etc/zivpn/user-db.json.tmp /etc/zivpn/user-db.json
                            systemctl restart zivpn
                        fi
                        """
                        subprocess.run(cmd_zivpn, shell=True)
                        domain_hasil = DOMAIN if 'DOMAIN' in globals() else "Premium Server"
                        
                    else:
                        # --- EKSEKUSI REMOTE (SG1, SG2, SG3) VIA PARAMIKO ---
                        if pilihan_server == "srv_sg1":
                            remote_ip = "165.245.182.117"
                            remote_pass = "Singgahvpn-18-November"
                            domain_hasil = "sg1.singgahvpn.web.id"
                        elif pilihan_server == "srv_sg2":
                            remote_ip = "68.183.191.42"
                            remote_pass = "Singgahvpn-11-December"
                            domain_hasil = "sg2.singgahvpn.web.id"
                        elif pilihan_server == "srv_sg3":
                            remote_ip = "143.198.80.108"
                            remote_pass = "Singgahvpn-02-November"
                            domain_hasil = "sg3.singgahvpn.web.id"

                        today = DT.date.today()
                        later = today + DT.timedelta(days=masa_aktif)
                        exp_date_str = later.strftime("%Y-%m-%d")
                        gen_date = today.strftime("%d/%m/%Y")
                        
                        # Rakit script Bash utuh untuk dieksekusi di server target
                        full_cmd = f"""
                        useradd -e $(date -d "{masa_aktif} days" +"%Y-%m-%d") -s /bin/false -M {username}
                        echo "{username}:{password}" | chpasswd
                        echo "{username} hard maxlogins {limit_ip}" >> /etc/security/limits.conf
                        
                        if [ -d "/etc/zivpn" ]; then
                            jq --arg u "{username}" '.auth.config += [$u]' /etc/zivpn/config.json > /etc/zivpn/config.json.tmp && mv /etc/zivpn/config.json.tmp /etc/zivpn/config.json
                            jq --arg u "{username}" --arg e "{exp_date_str}" --arg i "{limit_ip}" --arg q "{quota_gb}" '.[$u] = {{exp: $e, ip: $i, quota: $q}}' /etc/zivpn/user-db.json > /etc/zivpn/user-db.json.tmp && mv /etc/zivpn/user-db.json.tmp /etc/zivpn/user-db.json
                            systemctl restart zivpn
                        fi
                        """

                        try:
                            ssh_client = paramiko.SSHClient()
                            ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                            ssh_client.connect(hostname=remote_ip, port=22, username="root", password=remote_pass, timeout=15)
                            
                            stdin, stdout, stderr = ssh_client.exec_command(full_cmd)
                            
                            # PENTING: Tunggu sampai command bash di VPS benar-benar selesai
                            exit_status = stdout.channel.recv_exit_status() 
                            err_log = stderr.read().decode().strip()
                            
                            ssh_client.close()
                            
                            # Jika proses gagal, lempar error agar tidak dianggap sukses
                            if exit_status != 0 and "useradd: user" not in err_log:
                                raise Exception(f"Gagal create di server tujuan. Log: {err_log}")
                                
                        except Exception as remote_error:
                            raise Exception(f"Koneksi/Eksekusi ke {nama_server_terpilih} Gagal: {remote_error}")
                    # =========================================================
                    
                    sisa_saldo = database.get_saldo(user_id)
                    quota_str = "Unlimited" if quota_gb == 0 else f"{quota_gb} GB"

                    msg_sukses = f"""
<code>========================================
 AKUN SSH PREMIUM
========================================

 INFORMASI AKUN SSH
Server: {nama_server_terpilih}
Username: {username}
Domain: {domain_hasil}
Password: {password}
SSH WS: 80
SSH SSL WS: 443

 FORMAT KONEKSI
WS Format: {domain_hasil}:80@{username}:{password}
TLS Format: {domain_hasil}:443@{username}:{password}
UDP Format: {domain_hasil}:1-65535@{username}:{password}

 INFORMASI TAMBAHAN
Expired: {exp_date_str}
IP Limit: {limit_ip} Device
Quota: {quota_str}

========================================
ᵗᵉʳⁱᵐᵃᵏᵃˢⁱʰ ᵗᵉˡᵃʰ ᵐᵉⁿᵍᵍᵘⁿᵃᵏᵃⁿ ˡᵃʸᵃⁿᵃⁿ ᵏᵃᵐⁱ
Generated on {gen_date}
========================================
 DETAIL TRANSAKSI
Harga: Rp {harga_produk:,}
Sisa Saldo: Rp {sisa_saldo:,}</code>
"""
                    await msg_proc.edit(msg_sukses, parse_mode='html', buttons=[[Button.inline("‹ Kembali ke Menu ›", "menu_as_user")]])
                    
                    info_user_tg = f"{nama_pembeli} (<code>{user_id}</code>)"
                    await kirim_testimoni(
                        user_telegram=info_user_tg,
                        role_user="Member/Buyer",
                        tipe_akun="SSH Premium",
                        username_akun=username,
                        exp_days=masa_aktif,
                        quota_str=quota_str,
                        harga=harga_produk,
                        server_name=nama_server_terpilih
                    )
                    
                except Exception as e:
                    database.tambah_saldo(user_id, harga_produk, "REFUND: Gagal System")
                    await msg_proc.edit(f"❌ <b>Gagal System:</b> {str(e)}\nSaldo telah dikembalikan.", parse_mode='html')
            else:
                await msg_proc.edit("❌ <b>Transaksi Gagal:</b> Saldo tidak cukup.", parse_mode='html')

    except Exception as e:
        await event.respond(f"❌ <b>System Error:</b> {str(e)}", parse_mode='html')

# =================================================================
# 1. CREATE SSH (ADMIN MANUAL)
# =================================================================
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True); return

    async def create_ssh_process():
        try:
            async with bot.conversation(chat, timeout=120) as conv:
                await event.respond('<b>👤 Input Username:</b>', parse_mode='html')
                user_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                user = user_msg.raw_text.strip()
                if user == '/cancel': return await event.respond("❌ Dibatalkan.")
                
                await event.respond("<b>🔑 Input Password:</b>", parse_mode='html')
                pw_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pw = pw_msg.raw_text.strip()
                
                await event.respond("<b>📱 Max Login:</b>", parse_mode='html')
                limit_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                limit = limit_msg.raw_text.strip()
                
                await event.respond("<b>💾 Quota (GB):</b>\n(0 = Unlimited)", parse_mode='html')
                quota_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                quota = quota_msg.raw_text.strip()
                
                await event.respond("<b>📅 Masa Aktif (Hari):</b>", parse_mode='html')
                exp_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = exp_msg.raw_text.strip()

            msg_load = await event.respond("Creating...", parse_mode='html')
            
            # --- PENGAMAN ANTI-TYPO ---
            if not exp.isdigit() or not limit.isdigit() or not quota.isdigit():
                 return await msg_load.edit("<b>⚠️ Gagal:</b> Limit, Quota, dan Masa Aktif harus berupa ANGKA saja!", buttons=[[Button.inline("‹ Menu ›", "menu")]], parse_mode='html')

            cmd_sys = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{user}:{pw}" | chpasswd && echo "{user} hard maxlogins {limit}" >> /etc/security/limits.conf'
            
            try:
                # 1. Menjalankan perintah pembuatan user Linux
                subprocess.check_output(cmd_sys, shell=True, stderr=subprocess.STDOUT)
                
                # 2. Kalkulasi Tanggal & Quota
                today = DT.date.today()
                later = today + DT.timedelta(days=int(exp))
                exp_date_str = later.strftime("%Y-%m-%d")
                gen_date = today.strftime("%d/%m/%Y")
                quota_str = "Unlimited" if quota == '0' else f"{quota} GB"
                
                # 3. MENGAMBIL NAMA DOMAIN DARI VPS (YANG BENAR)
                try:
                    with open("/etc/xray/domain", "r") as f:
                        domain_hasil = f.read().strip()
                except:
                    domain_hasil = "Domain-Tidak-Terbaca"
                
                # 4. Memasukkan data ke Database ZiVPN
                cmd_zivpn = f"""
                jq --arg u "{user}" '.auth.config += [$u]' /etc/zivpn/config.json > /etc/zivpn/config.json.tmp && mv /etc/zivpn/config.json.tmp /etc/zivpn/config.json && \
                jq --arg u "{user}" --arg e "{exp_date_str}" --arg i "{limit}" --arg q "{quota}" '.[$u] = {{exp: $e, ip: $i, quota: $q}}' /etc/zivpn/user-db.json > /etc/zivpn/user-db.json.tmp && mv /etc/zivpn/user-db.json.tmp /etc/zivpn/user-db.json && \
                systemctl restart zivpn
                """
                subprocess.run(cmd_zivpn, shell=True)
                
                # 5. Menampilkan Struk Sukses
                msg_complete = f"""
<code>========================================
 AKUN SSH PREMIUM
========================================

 INFORMASI AKUN SSH
Username: {user}
Domain: {domain_hasil}
Password: {pw}
SSH WS: 80
SSH SSL WS: 443

 FORMAT KONEKSI
WS Format: {domain_hasil}:80@{user}:{pw}
TLS Format: {domain_hasil}:443@{user}:{pw}
UDP Format: {domain_hasil}:1-65535@{user}:{pw}

 INFORMASI TAMBAHAN
Expired: {exp_date_str}
IP Limit: {limit} Device
Quota: {quota_str}

========================================
ᵗᵉʳⁱᵐᵃᵏᵃˢⁱʰ ᵗᵉˡᵃʰ ᵐᵉⁿᵍᵍᵘⁿᵃᵏᵃⁿ ˡᵃʸᵃⁿᵃⁿ ᵏᵃᵐⁱ
Generated on {gen_date}
========================================</code>
"""
                await msg_load.edit(msg_complete, buttons=[[Button.inline("‹ Menu ›", "menu")]], parse_mode='html')
                
                # 6. Kirim Testimoni ke Channel/Group Admin
                await kirim_testimoni(
                    user_telegram=f"{sender.first_name} (Admin)",
                    role_user="Admin/Owner",
                    tipe_akun="SSH Premium",
                    username_akun=user,
                    exp_days=exp,
                    quota_str=quota_str,
                    harga="0 (Created by Admin)",
                    server_name=domain_hasil
                )
                
            except subprocess.CalledProcessError as e:
                err_msg = e.output.decode('utf-8').strip() if e.output else "Unknown Linux Error"
                await msg_load.edit(f"<b>⚠️ Error Sistem Linux:</b>\n<code>{err_msg}</code>", buttons=[[Button.inline("‹ Menu ›", "menu")]], parse_mode='html')
            except Exception as e:
                await msg_load.edit(f"<b>⚠️ Error Bot Python:</b>\n<code>{str(e)}</code>", buttons=[[Button.inline("‹ Menu ›", "menu")]], parse_mode='html')

        except AlreadyInConversationError:
            await event.answer("⚠️ Sedang ada proses lain! Ketik /cancel dulu.", alert=True)
        except asyncio.TimeoutError:
            await event.respond("<b>⚠️ Waktu Habis. Silakan ulangi.</b>", buttons=[[Button.inline("‹ Menu ›", "menu")]], parse_mode='html')
        except Exception as e:
            await event.respond(f"Error Timeout/Conversation: {e}")

    await create_ssh_process()

# =================================================================
# 2. DELETE SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
    chat = event.chat_id; sender = await event.get_sender()
    if valid(str(sender.id)) != "true": await event.answer("Akses Ditolak", alert=True); return
    async def del_proc():
        try:
            async with bot.conversation(chat, timeout=60) as conv:
                await event.respond("<b>🗑️ Username:</b>", parse_mode='html')
                user_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                user = user_msg.raw_text.strip()
                if user == '/cancel': return await event.respond("❌ Batal")
            
            subprocess.run(f"userdel -f {user} && sed -i '/^{user} hard/d' /etc/security/limits.conf", shell=True)
            subprocess.run(f"jq --arg u '{user}' '.auth.config -= [$u] | del(.[$u])' /etc/zivpn/user-db.json > /tmp/db && mv /tmp/db /etc/zivpn/user-db.json", shell=True)
            await event.respond(f"✅ Deleted: {user}", buttons=[[Button.inline("‹ Menu ›", "menu")]])
        except: pass
    await del_proc()

# =================================================================
# 3. TRIAL SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    chat = event.chat_id; sender = await event.get_sender()
    if valid(str(sender.id)) != "true": await event.answer("Akses Ditolak", alert=True); return
    async def trial_proc():
        try:
            async with bot.conversation(chat, timeout=60) as conv:
                await event.respond("<b>⏱️ Menit:</b>", parse_mode='html')
                exp_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = exp_msg.raw_text.strip()
            
            user = "trial"+str(random.randint(100,999)); pw="1"
            subprocess.run(f'useradd -e "`date -d "{exp} minutes" +"%Y-%m-%d %H:%M:%S"`" -s /bin/false -M {user} && echo "{user}:{pw}" | chpasswd', shell=True)
            
            tomorrow = DT.date.today() + DT.timedelta(days=1); exp_date_str = tomorrow.strftime("%Y-%m-%d")
            cmd_zivpn = f"""jq --arg u "{user}" '.auth.config += [$u]' /etc/zivpn/config.json > /etc/zivpn/config.json.tmp && mv /etc/zivpn/config.json.tmp /etc/zivpn/config.json && jq --arg u "{user}" --arg e "{exp_date_str}" --arg i "1" --arg q "1" '.[$u] = {{exp: $e, ip: "1", quota: "1"}}' /etc/zivpn/user-db.json > /etc/zivpn/user-db.json.tmp && mv /etc/zivpn/user-db.json.tmp /etc/zivpn/user-db.json && systemctl restart zivpn"""
            subprocess.run(cmd_zivpn, shell=True)

            msg_trial = f"""
<code>========================================
 AKUN SSH TRIAL
========================================

 Username: {user}
 Password: {pw}
 Expired : {exp} Menit
 Domain  : {DOMAIN}

 WS Format: {DOMAIN}:80@{user}:{pw}
 TLS Format: {DOMAIN}:443@{user}:{pw}
 UDP Format: {DOMAIN}:1-65535@{user}:{pw}
========================================</code>
"""
            await event.respond(msg_trial, buttons=[[Button.inline("‹ Menu ›", "menu")]], parse_mode='html')
        except: pass
    await trial_proc()

# =================================================================
# 4. SHOW, MONITOR, REGIS, MENU
# =================================================================
@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
    if valid(str(event.sender_id)) != "true": return
    data = get_ssh_data(); msg, total = render_page(data, 0)
    btns = [[Button.inline("Next ⏩", "sshPage_1")]] if total > 1 else []
    btns.append([Button.inline("‹ Menu ›", "menu")])
    await event.edit(msg, buttons=btns, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b'sshPage_(\d+)'))
async def pag_ssh(event):
    page = int(event.data.decode().split('_')[1])
    data = get_ssh_data(); msg, total = render_page(data, page)
    nav = []
    if page > 0: nav.append(Button.inline("⏪ Prev", f"sshPage_{page-1}"))
    if page < total - 1: nav.append(Button.inline("Next ⏩", f"sshPage_{page+1}"))
    btns = [nav] if nav else []; btns.append([Button.inline("‹ Menu ›", "menu")])
    await event.edit(msg, buttons=btns, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh_h(event):
    await event.answer("Fitur Monitor (Gunakan bot monitor)", alert=False) 

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh_menu(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true": return await event.answer("Access Denied", alert=True)
    inline = [
        [Button.inline("☁️ TRIAL SSH ","trial-ssh"), Button.inline("⚡ CREATE SSH ","create-ssh")],
        [Button.inline("🗑️ DELETE SSH ","delete-ssh"), Button.inline("🔐 CHECK LOGIN","login-ssh")],
        [Button.inline("📊 LIST USER SSH ","show-ssh")], [Button.inline("‹ Main Menu ›","menu")]
    ]
    await event.edit("<b>☁️ SSH MANAGER</b>", buttons=inline, parse_mode='html')