from kyt import *
from telethon import events, Button
from kyt.modules import harga, config, database, atlantic
import subprocess
import requests
import random
import io
import urllib.parse
import os
import json
import time
import asyncio
from telethon import errors
import datetime
import re
import math
import paramiko
# =================================================================
# GLOBAL VARIABLES (STATE MACHINE)
# =================================================================
user_states = {}   # Untuk User Topup
admin_states = {}  # Untuk Admin Manage User
admin_context = {} # Penyimpanan data sementara Admin

# --- DATABASE FILES ---
WD_FILE = '/usr/bin/kyt/modules/wd_list.json'
BLACKLIST_FILE = '/usr/bin/kyt/modules/blacklist.json' # FILE DATABASE BAN

# --- KONFIGURASI ADMIN UNTUK TOPUP MANUAL ---
ADMIN_WA = "6283169627250"  # Format: 628xx (Tanpa +)
ADMIN_TG = "SinggahPremium"  # Username tanpa @
VPS_SERVERS = {
    "sg1": {
        "name": "Server 1 (SG1)",
        "ip": "165.245.182.117",
        "domain": "sg1.singgahvpn.web.id",
        "pass": "Singgahvpn-18-November"
    },
    "sg2": {
        "name": "Server 2 (SG2)",
        "ip": "68.183.191.42",
        "domain": "sg2.singgahvpn.web.id",
        "pass": "Singgahvpn-11-December"
    },
    "sg3": {
        "name": "Server 3 (SG3)",
        "ip": "143.198.80.108",
        "domain": "sg3.singgahvpn.web.id",
        "pass": "Singgahvpn-02-November"
    }
}
# =================================================================
# FUNGSI TAMBAHAN: BLACKLIST SYSTEM
# =================================================================
def load_blacklist():
    if not os.path.exists(BLACKLIST_FILE): return []
    try:
        with open(BLACKLIST_FILE, 'r') as f: return json.load(f)
    except: return []

def save_blacklist(data):
    # Pastikan folder ada
    os.makedirs(os.path.dirname(BLACKLIST_FILE), exist_ok=True)
    with open(BLACKLIST_FILE, 'w') as f: json.dump(data, f, indent=4)

def check_is_banned(user_id):
    """Cek apakah user dilarang akses bot"""
    banned_list = load_blacklist()
    return str(user_id) in banned_list

# FUNGSI CEK PROFILE RAMASHOP (Nama fungsi tetap cek_atlantic agar kode lain tidak error)
def cek_atlantic():
    try:
        # Panggil fungsi get_saldo() dari file atlantic.py yang baru
        res = atlantic.get_saldo()
        
        if res.get('success') or res.get('status') == True:
            data = res.get('data', {})
            # Ambil username dan balance dari format Ramashop
            nama = data.get('username', 'Unknown')
            saldo = data.get('balance', 0)
            return nama, f"Rp {int(saldo):,}".replace(",", ".")
        else:
            return f"Err: {res.get('message', 'Gagal')}", "Rp 0"
    except:
        return "Connection Error", "Rp 0"

# =================================================================
# MENU HANDLER (DENGAN PENGECEKAN BAN & STATUS MULTI-VPS)
# =================================================================
@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
@bot.on(events.CallbackQuery(data=b'menu_as_user'))
async def menu_handler(event):
    try:
        sender = await event.get_sender()
        user_id = sender.id
        first_name = sender.first_name
        
        # --- [LOGIKA CEK BANNED - SYSTEM KICK] ---
        if check_is_banned(user_id):
            return await event.respond("🚫 <b>AKSES DITOLAK</b>\n\nMaaf, akun Anda telah <b>DIBLOKIR PERMANEN</b> oleh Admin karena pelanggaran aturan.\nAnda tidak dapat menggunakan bot ini lagi.", parse_mode='html')
        # ------------------------------------------

        # Reset State saat buka menu
        if user_id in user_states: del user_states[user_id]
        if user_id in admin_states: del admin_states[user_id]
    except:
        user_id = "Unknown"; first_name = "User"

    if isinstance(event, events.CallbackQuery.Event):
        await event.answer()

    try:
        is_real_admin = False
        try:
            if valid(str(user_id)) == "true": is_real_admin = True
        except: pass

        view_as_user = False
        if hasattr(event, 'data') and event.data == b'menu_as_user':
            view_as_user = True

        if is_real_admin and not view_as_user:
            try:
                ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()
            except: ipsaya = "127.0.0.1"

            atl_nama, atl_saldo = cek_atlantic()

            # --- RUMUS UNTUK MENAMPILKAN 3 VPS + CEK STATUS ---
            list_server_text = ""
            try:
                for vps_id, data in VPS_SERVERS.items():
                    ip_target = data['ip']
                    icon_status = "🔴"
                    
                    try:
                        # Cek port SSH dengan sangat cepat (1 detik)
                        conn = asyncio.open_connection(ip_target, 22)
                        reader, writer = await asyncio.wait_for(conn, timeout=1.0)
                        writer.close()
                        await writer.wait_closed()
                        icon_status = "🟢"
                    except Exception:
                        pass # Biarkan tetap merah jika Firewall memblokir IP Pusat
                    
                    list_server_text += f"├ {icon_status} <b>{data['name']}</b> : <code>{ip_target}</code>\n"
            except Exception as e:
                list_server_text = f"├ <i>Error load VPS: {e}</i>\n"
            # -------------------------------------
            except Exception as e:
                list_server_text = f"├ <i>Error load VPS: {e}</i>\n"
            # -------------------------------------
           

            msg = f"""
<b>👑 ADMIN CONTROL PANEL</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>👤 Admin :</b> {first_name}
<b>📡 IP Pusat:</b> <code>{ipsaya}</code>

<b>🌐 VPS REMOTE TERHUBUNG:</b>
{list_server_text}
<b>💰 RAMASHOP API PROFILE</b>
<b>👤 Nama  :</b> <code>{atl_nama}</code>
<b>💵 Saldo :</b> <code>{atl_saldo}</code>

<b>📊 MENU MANAJEMEN:</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
"""
            buttons = [
                [Button.inline("☁️ SSH OVPN", data="ssh"), Button.inline("⚡ VMESS", data="vmess")],
                [Button.inline("🚀 VLESS", data="vless"), Button.inline("🛡 TROJAN", data="trojan")],
                [Button.inline("👻 SHADOWSOCKS", data="shadowsocks"), Button.inline("⚙️ SETTINGS", data="setting")],
                [Button.inline("🖥 MANAGE SERVER", data="server_list"), Button.inline("📝 REGIS IP", data="regis")],
                [Button.inline("👥 MANAGE USER", data="manage_users"), Button.inline("💸 WITHDRAW", data="adm_wd_start")],
                [Button.inline("📢 BROADCAST USER", data="adm_broadcast_start")],
                [Button.inline("🔙 KEMBALI", data="start")]
            ]
        else:
            database.cek_user(user_id, sender.username if hasattr(sender, 'username') else 'User')
            saldo_asli = database.get_saldo(user_id)
            rp_saldo = f"Rp {saldo_asli:,}".replace(",", ".")

            msg = f"""
<b>🛒 SINGGAH VPN STORE</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Halo <b>{first_name}</b>! 👋
Silakan pilih kategori layanan di bawah ini.

🆔 <b>ID Anda :</b> <code>{user_id}</code>
💰 <b>Saldo :</b> <code>{rp_saldo}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

<b>👇 PILIH KATEGORI PRODUK:</b>
"""
            buttons = [
                [Button.inline("☁️ SSH/ZiVPN/OVPN", data="cat_SSH"), Button.inline("⚡ VMESS", data="cat_VMESS")],
                [Button.inline("🚀 VLESS", data="cat_VLESS"), Button.inline("🛡 TROJAN", data="cat_TROJAN")],
                [Button.inline("👻 SHADOWSOCKS", data="cat_SHADOWSOCKS"), Button.inline("💰 TOP UP SALDO", data="topup")],
                [Button.inline("📜 RIWAYAT TRANSAKSI", data="riwayat")],
                [Button.url("💬 HUBUNGI ADMIN", "https://t.me/SinggahPremium"), Button.inline("🔙 REFRESH", data="menu_as_user")]
            ]
            if is_real_admin: buttons.append([Button.inline("👑 KEMBALI KE ADMIN PANEL", data="menu")])
            buttons.append([Button.inline("🔙 MENU UTAMA", data="start")])

        if isinstance(event, events.CallbackQuery.Event):
            try:
                await event.edit(msg, buttons=buttons, parse_mode='html')
            except errors.MessageNotModifiedError:
                await event.answer("✅ Data sudah paling update!", alert=False)
            except Exception as e:
                if "not modified" in str(e):
                    await event.answer("✅ Data sudah paling update!", alert=False)
                else:
                    raise e
        else:
            await event.reply(msg, buttons=buttons, parse_mode='html')

    except Exception as e:
        try: await event.respond(f"❌ <b>ERROR:</b> {str(e)}", parse_mode='html')
        except: pass

# =================================================================
# HANDLER MANAGE USER & SALDO (ADMIN)
# =================================================================
@bot.on(events.CallbackQuery(data=b'manage_users'))
async def manage_users_handler(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Akses Ditolak!", alert=True)
    
    users = database.get_all_users(limit=15)
    
    msg = "<b>👥 MANAJEMEN USER & SALDO</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    msg += "<i>Menampilkan Top 15 User (Urut Saldo):</i>\n\n"
    
    if not users:
        msg += "⚠️ Belum ada user terdaftar."
    else:
        for u in users:
            uid, uname, saldo = u
            uname = uname if uname else "Unknown"
            # Cek status visual
            is_banned = check_is_banned(uid)
            status_icon = "🚫 BANNED" if is_banned else "✅"
            
            msg += f"{status_icon} 🆔 <code>{uid}</code> | 💰 Rp {saldo:,}\n👤 {uname}\n───────────────────\n"
            
    msg += "\n<b>👇 PILIH AKSI:</b>"
    
    buttons = [
        [Button.inline("➕ TAMBAH SALDO", data="adm_add_saldo"), Button.inline("➖ KURANG SALDO", data="adm_min_saldo")],
        # --- TOMBOL BARU BAN/UNBAN ---
        [Button.inline("🚫 BAN USER (KICK)", data="adm_ban_start"), Button.inline("✅ UNBAN USER", data="adm_unban_start")],
        [Button.inline("🔙 KEMBALI", data="menu")]
    ]
    await event.edit(msg, buttons=buttons, parse_mode='html')

# 1. TRIGGER TOMBOL BAN/UNBAN
@bot.on(events.CallbackQuery(pattern=b'adm_(ban|unban)_start'))
async def admin_ban_trigger(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true": return

    action = event.data.decode('utf-8')
    tipe_aksi = "BAN" if "ban_start" in action and "unban" not in action else "UNBAN"

    # Set State Admin
    admin_states[sender.id] = 'WAIT_TARGET_BAN' if tipe_aksi == "BAN" else 'WAIT_TARGET_UNBAN'

    desc = "User akan <b>DIBLOKIR</b> dan tidak bisa akses bot." if tipe_aksi == "BAN" else "Akses user akan <b>DIPULIHKAN</b>."

    msg = f"""
<b>🛡️ {tipe_aksi} USER MANAGER</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Silakan kirim <b>ID Telegram User</b>.
(Lihat ID di list sebelumnya)

<i>{desc}</i>
"""
    btn_batal = [[Button.inline("❌ BATAL / KEMBALI", data="manage_users")]]
    await event.edit(msg, buttons=btn_batal, parse_mode='html')

# 2. TRIGGER TOMBOL TAMBAH/KURANG SALDO
@bot.on(events.CallbackQuery(pattern=b'adm_(add|min)_saldo'))
async def admin_saldo_start(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true": return
    
    action = event.data.decode('utf-8')
    tipe_aksi = "TAMBAH" if "add" in action else "KURANG"
    
    # SET STATE: Menunggu ID User
    admin_states[sender.id] = 'WAIT_TARGET_ID'
    admin_context[sender.id] = {'type': tipe_aksi}
    
    btn_batal = [[Button.inline("❌ BATAL / KEMBALI", data="cancel_admin_process")]]
    
    await event.edit(f"<b>📝 {tipe_aksi} SALDO USER</b>\n\nSilakan kirim <b>ID Telegram User</b>.\n(Lihat ID di list sebelumnya)\n\nAtau Klik tombol Batal dibawah.", buttons=btn_batal, parse_mode='html')

# 3. TRIGGER TOMBOL BATAL UMUM
@bot.on(events.CallbackQuery(data=b'cancel_admin_process'))
async def cancel_admin_handler(event):
    user_id = event.sender_id
    # Hapus State
    if user_id in admin_states: del admin_states[user_id]
    if user_id in admin_context: del admin_context[user_id]
    
    await event.edit("❌ <b>Proses Dibatalkan.</b>", buttons=[[Button.inline("🔙 Menu Admin", data="manage_users")]], parse_mode='html')

# 4. HANDLER INPUT TEXT ADMIN (STATE MACHINE GABUNGAN)
@bot.on(events.NewMessage(incoming=True))
async def admin_input_handler(event):
    user_id = event.sender_id
    
    # Cek apakah user ini Admin yg sedang input data?
    if user_id not in admin_states:
        return # Bukan urusan handler ini
        
    state = admin_states[user_id]
    text = event.raw_text.strip()
    
    # Command Batal Global
    if text == '/cancel':
        if user_id in admin_states: del admin_states[user_id]
        if user_id in admin_context: del admin_context[user_id]
        return await event.reply("❌ Proses Dibatalkan.", buttons=[[Button.inline("🔙 Menu Admin", data="menu")]])

    btn_batal = [[Button.inline("❌ BATAL / KEMBALI", data="cancel_admin_process")]]

    # =================================================================
    # LOGIKA BAN / UNBAN USER
    # =================================================================
    if state == 'WAIT_TARGET_BAN':
        target_id = text
        if not target_id.isdigit(): return await event.reply("⚠️ ID harus angka.")
        
        banned_list = load_blacklist()
        
        if target_id in banned_list:
             await event.reply(f"⚠️ User ID <code>{target_id}</code> sudah dibanned sebelumnya.", buttons=[[Button.inline("🔙 Kembali", data="manage_users")]], parse_mode='html')
        else:
            banned_list.append(target_id)
            save_blacklist(banned_list)
            # Pesan Sukses
            await event.reply(f"🚫 <b>SUKSES BAN USER</b>\n\nID: <code>{target_id}</code>\nUser ini sekarang tidak bisa mengakses bot lagi.", buttons=[[Button.inline("🔙 Kembali", data="manage_users")]], parse_mode='html')
        
        del admin_states[user_id] # Reset state

    elif state == 'WAIT_TARGET_UNBAN':
        target_id = text
        banned_list = load_blacklist()
        
        if target_id in banned_list:
            banned_list.remove(target_id)
            save_blacklist(banned_list)
            await event.reply(f"✅ <b>SUKSES UNBAN USER</b>\n\nID: <code>{target_id}</code>\nUser ini sekarang bisa mengakses bot kembali.", buttons=[[Button.inline("🔙 Kembali", data="manage_users")]], parse_mode='html')
        else:
            await event.reply(f"⚠️ User ID <code>{target_id}</code> tidak ditemukan di daftar ban.", buttons=[[Button.inline("🔙 Kembali", data="manage_users")]], parse_mode='html')

        del admin_states[user_id] # Reset state

    # =================================================================
    # LOGIKA BROADCAST (SIARAN PESAN)
    # =================================================================
    elif state == 'WAIT_BROADCAST_MSG':
        # Konfirmasi Pengiriman
        msg_wait = await event.reply("🔄 <b>Sedang Mengirim Broadcast...</b>\n<i>Mohon tunggu, jangan spam...</i>", parse_mode='html')
        
        # Ambil semua user
        all_users = database.get_all_users() 
        
        sukses = 0
        gagal = 0
        total = len(all_users)
        
        start_time = time.time()
        
        btn_untuk_user = [[Button.inline("🔙 Menu Utama", data="menu_as_user")]]

        for user in all_users:
            try:
                target_id = int(user[0]) 
                
                # BARIS BARU (Kirim pesan + Tombol)
                await bot.send_message(target_id, event.message, buttons=btn_untuk_user)
                
                sukses += 1
                await asyncio.sleep(0.05) 
            except Exception as e:
                gagal += 1
                continue

        end_time = time.time()
        durasi = round(end_time - start_time, 2)
        
        # Hapus State Admin (Agar tidak nyangkut)
        if user_id in admin_states: del admin_states[user_id]
        
        laporan = f"""
<b>✅ BROADCAST SELESAI</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>📊 Total User:</b> {total}
<b>✅ Sukses:</b> {sukses}
<b>❌ Gagal:</b> {gagal} (Blokir bot)
<b>⏱️ Durasi:</b> {durasi} detik
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
"""
        # --- UPDATE TOMBOL KEMBALI ---
        buttons_selesai = [
            [Button.inline("📢 Broadcast Lagi", data="adm_broadcast_start")],
            [Button.inline("🔙 Kembali ke Menu Utama", data="menu")]
        ]
        
        await msg_wait.edit(laporan, buttons=buttons_selesai, parse_mode='html')
        return

    # =================================================================
    # LOGIKA MANAGE SALDO (TAMBAH/KURANG)
    # =================================================================
    
    # --- TAHAP 1: TERIMA ID USER ---
    elif state == 'WAIT_TARGET_ID':
        if not text.isdigit():
            return await event.reply("❌ <b>ID harus angka!</b> Silakan kirim ID yang benar.", buttons=btn_batal, parse_mode='html')
        
        target_id = text
        admin_context[user_id]['target_id'] = target_id
        
        # Cek Saldo User
        saldo_curr = database.get_saldo(target_id)
        
        # Lanjut ke Tahap 2: Minta Nominal
        admin_states[user_id] = 'WAIT_NOMINAL'
        
        tipe = admin_context[user_id]['type']
        await event.reply(f"✅ ID Diterima: <code>{target_id}</code>\n💰 Saldo Sekarang: Rp {saldo_curr:,}\n\n<b>Masukan Nominal {tipe}:</b>\nContoh: 50000", buttons=btn_batal, parse_mode='html')
    # =================================================================
    # LOGIKA REGIS IP
    # =================================================================
    elif state == 'WAIT_IP_REGIS':
        ip_target = text.strip()
        
        # Validasi format IP sederhana
        if not ip_target.replace('.', '').isdigit() or ip_target.count('.') != 3:
            return await event.reply("⚠️ <b>Format IP Salah!</b>\nContoh: <code>192.168.1.1</code>", buttons=btn_batal, parse_mode='html')

        msg_wait = await event.reply(f"🔄 Mendaftarkan IP: <code>{ip_target}</code>...", parse_mode='html')

        try:
            # --- EKSEKUSI SKRIP PENDAFTARAN IP ---
            subprocess.check_output(f'echo "{ip_target}" >> /usr/bin/kyt/modules/ip_list.txt', shell=True) 
            
            # Hapus State
            del admin_states[user_id]
            
            hasil = f"""
<b>✅ REGIS IP BERHASIL</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>IP:</b> <code>{ip_target}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<i>IP telah disimpan ke database/whitelist.</i>
"""
            await msg_wait.edit(hasil, buttons=[[Button.inline("🔙 Menu Admin", data="menu")]], parse_mode='html')
            
        except Exception as e:
            await msg_wait.edit(f"❌ <b>Gagal:</b> {str(e)}", buttons=btn_batal, parse_mode='html')
    
# =================================================================
    # LOGIKA CREATE AKUN (BYPASS SALDO ADMIN)
    # =================================================================
    elif state == 'ADM_CREATE_USER':
        username = text.replace(" ", "")
        admin_context[user_id]['username'] = username

        layanan = admin_context[user_id]['layanan']
        if layanan == "SSH":
            admin_states[user_id] = 'ADM_CREATE_PASS'
            await event.reply(f"✅ Username: <b>{username}</b>\n\nSilakan masukkan <b>Password</b> untuk akun SSH:", parse_mode='html')
        else:
            admin_states[user_id] = 'ADM_CREATE_HARI'
            await event.reply(f"✅ Username: <b>{username}</b>\n\nSilakan masukkan <b>Durasi/Expired (Hari)</b> (Angka saja):", parse_mode='html')

    elif state == 'ADM_CREATE_PASS':
        admin_context[user_id]['password'] = text
        admin_states[user_id] = 'ADM_CREATE_HARI'
        await event.reply(f"✅ Password tersimpan.\n\nSilakan masukkan <b>Durasi/Expired (Hari)</b> (Angka saja):", parse_mode='html')

    elif state == 'ADM_CREATE_HARI':
        if not text.isdigit():
            return await event.reply("⚠️ Durasi harus berupa angka (hari)!")
        durasi = text

        ctx = admin_context[user_id]
        vps_id = ctx['vps_id']
        layanan = ctx['layanan']
        username = ctx['username']
        password = ctx.get('password', '1') # Password default "1" jika selain SSH (sebagai filler script)

        vps_data = VPS_SERVERS[vps_id]
        ip = vps_data['ip']
        pw_vps = vps_data['pass']

        msg_wait = await event.reply(f"⏳ <b>Membuat akun {layanan} di server {vps_data['name']}...</b>", parse_mode='html')

        try:
            # Sesuaikan dengan command script auto-install di VPS kamu
            if layanan == "SSH":
                cmd = f"usernew {username} {password} {durasi}"
            elif layanan == "VMESS":
                cmd = f"add-ws {username} {durasi}"
            elif layanan == "VLESS":
                cmd = f"add-vless {username} {durasi}"
            elif layanan == "TROJAN":
                cmd = f"add-tr {username} {durasi}"
            elif layanan == "SS":
                cmd = f"add-ss {username} {durasi}"
            else:
                cmd = ""

            # Eksekusi via Paramiko ke server tujuan
            ssh_client = paramiko.SSHClient()
            ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh_client.connect(hostname=ip, port=22, username="root", password=pw_vps, timeout=15)
            stdin, stdout, stderr = ssh_client.exec_command(cmd)
            output = stdout.read().decode().strip()
            ssh_client.close()

            # Bersihkan state admin
            del admin_states[user_id]
            del admin_context[user_id]

            hasil_msg = f"""
<b>✅ BERHASIL CREATE (STATUS: OWNER)</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<code>{output}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<i>Akun berhasil dibuat tanpa memotong saldo.</i>
"""
            await msg_wait.edit(hasil_msg, parse_mode='html')
            
            # Opsional: Jika ingin tetap merekam di database riwayat tanpa harga
            # import time
            # trx_id = f"ADM{int(time.time())}"
            # ket = f"Beli {layanan} {durasi} Hari (OWNER) | Akun: {username} | Pass/UUID: {password}"
            # database.insert_riwayat(user_id, trx_id, "CREATE", 0, "SUCCESS", ket)

        except Exception as e:
            await msg_wait.edit(f"❌ <b>Gagal mengeksekusi script di VPS tujuan:</b>\n{str(e)}", parse_mode='html')
            del admin_states[user_id]
            del admin_context[user_id]
    
    # --- TAHAP 2: TERIMA NOMINAL ---
    elif state == 'WAIT_NOMINAL':
        if not text.isdigit():
            return await event.reply("❌ <b>Nominal harus angka!</b> Contoh: 50000", buttons=btn_batal, parse_mode='html')
            
        nominal = int(text)
        data_ctx = admin_context[user_id]
        target_id = data_ctx['target_id']
        tipe = data_ctx['type']
        
        msg_wait = await event.reply("🔄 Memproses...", parse_mode='html')
        
        try:
            if tipe == "TAMBAH":
                database.tambah_saldo(target_id, nominal, "Topup Manual Admin")
                ket_admin = "✅ BERHASIL NAMBAH SALDO"
                ket_notif_title = "💰 SALDO MASUK"
                ket_desc = "Penambahan"
            else:
                curr = database.get_saldo(target_id)
                if curr < nominal:
                    return await msg_wait.edit(f"❌ <b>GAGAL:</b> Saldo user cuma Rp {curr:,}. Tidak bisa dikurangi Rp {nominal:,}.", buttons=btn_batal, parse_mode='html')
                
                database.kurang_saldo(target_id, nominal, "Penyesuaian Admin")
                ket_admin = "✅ BERHASIL POTONG SALDO"
                ket_notif_title = "💸 SALDO KELUAR"
                ket_desc = "Pengurangan"
            
            # Reset State Admin (Selesai)
            del admin_states[user_id]
            del admin_context[user_id]
            
            # 1. Info ke Admin
            msg_done = f"""
<b>{ket_admin}</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🆔 User    :</b> <code>{target_id}</code>
<b>💰 Nominal:</b> Rp {nominal:,}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<i>Saldo user telah diperbarui.</i>
"""
            # Tombol Selesai untuk Saldo
            await msg_wait.edit(msg_done, buttons=[[Button.inline("🔙 Kembali ke Menu Admin", data="manage_users")]], parse_mode='html')
            
            # 2. Notif Mewah ke User
            try:
                # Ambil saldo terbaru user utk ditampilkan
                sisa_saldo_user = database.get_saldo(target_id)
                
                msg_user = f"""
<b>{ket_notif_title}</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Halo, Admin telah melakukan <b>{ket_desc}</b> saldo pada akun Anda.

<b>💵 Nominal :</b> <code>Rp {nominal:,}</code>
<b>💳 Sisa Saldo:</b> <code>Rp {sisa_saldo_user:,}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<i>Silakan cek kembali profil Anda.</i>
"""
                # Tombol untuk User
                btn_user = [
                    [Button.inline("👤 CEK PROFIL", data="menu_as_user")]
                ]
                
                await bot.send_message(int(target_id), msg_user, buttons=btn_user, parse_mode='html')
            except Exception as e:
                pass
            
        except Exception as e:
            await msg_wait.edit(f"❌ Error Database: {e}", buttons=btn_batal)

# =================================================================
# HANDLER LAINNYA
# =================================================================
@bot.on(events.CallbackQuery(pattern=b'cat_'))
async def category_handler(event):
    try:
        kategori_pilih = event.data.decode('utf-8').split('_')[1]
        msg = f"<b>📦 KATEGORI: {kategori_pilih}</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n<i>Silakan pilih paket:</i>\n"
        buttons = []
        found = False
        for kode, info in harga.daftar_produk.items():
            if info['service'] == kategori_pilih:
                found = True
                nama = info['nama']; harga_rp = harga.format_rupiah(info['harga'])
                buttons.append([Button.inline(f"{nama} - {harga_rp}", data=f"buy_{kode}")])
        if not found: msg += "\n❌ <i>Produk belum tersedia.</i>"
        buttons.append([Button.inline("🔙 KEMBALI", data="menu_as_user")])
        await event.edit(msg, buttons=buttons, parse_mode='html')
    except: pass

@bot.on(events.CallbackQuery(pattern=b'buy_'))
async def buy_confirm_handler(event):
    try:
        kode_produk = event.data.decode('utf-8').split('_', 1)[1]
        if kode_produk in harga.daftar_produk:
            info = harga.daftar_produk[kode_produk]
            
            # Default callback untuk pembelian (INI YANG BENAR UNTUK USER)
            callback_fix = f"fix_buy_{kode_produk}"
            
            service_type = info['service'].upper()
            
            msg = f"""
<b>🛒 KONFIRMASI PEMBELIAN</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>📦 Paket :</b> {info['nama']}
<b>💰 Harga :</b> {harga.format_rupiah(info['harga'])}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<i>Pastikan saldo Anda cukup.</i>
"""
            buttons = [
                [Button.inline("✅ BELI", data=callback_fix)], 
                [Button.inline("❌ BATAL", data=f"cat_{info['service']}")]
            ]
            await event.edit(msg, buttons=buttons, parse_mode='html')
    except Exception as e:
        pass

# =================================================================
# SUB-MENU RIWAYAT TRANSAKSI
# =================================================================
@bot.on(events.CallbackQuery(data=b'riwayat'))
async def history_menu_handler(event):
    msg = """
<b>📜 MENU RIWAYAT TRANSAKSI</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Silakan pilih jenis riwayat yang ingin Anda lihat:
"""
    buttons = [
        [Button.inline("🛒 RIWAYAT PEMBELIAN (SSH/VPN)", data="riwayat_beli")],
        [Button.inline("💳 RIWAYAT TOP UP SALDO", data="riwayat_topup")],
        [Button.inline("🔙 KEMBALI KE MENU UTAMA", data="menu_as_user")]
    ]
    await event.edit(msg, buttons=buttons, parse_mode='html')

# =================================================================
# TAMPILAN RIWAYAT PEMBELIAN (DENGAN FORMAT RAPI)
# =================================================================
@bot.on(events.CallbackQuery(pattern=re.compile(b"riwayat_beli(?:_(\d+))?")))
async def history_beli_handler(event):
    import datetime
    import re
    import math
    
    user_id = event.sender_id
    
    # Ambil argumen halaman (default 0)
    match = event.pattern_match.group(1)
    page = int(match.decode()) if match else 0
    
    data_trx = database.get_riwayat(user_id, limit=100) 
    
    riwayat_beli = []
    if data_trx:
        for row in data_trx:
            trx_id, tipe, jml, sts, tgl, ket = row
            
            # Abaikan jika statusnya sudah dihapus
            if sts == 'DELETED':
                continue
                
            ket_lower = str(ket).lower()
            if "beli" in ket_lower or "order" in ket_lower or "kurang" in ket_lower:
                riwayat_beli.append(row)

    item_per_page = 5 
    total_items = len(riwayat_beli)
    total_pages = math.ceil(total_items / item_per_page)
    
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    
    start = page * item_per_page
    end = start + item_per_page
    sliced_data = riwayat_beli[start:end]

    msg = f"<b>🛒 RIWAYAT PEMBELIAN (Page {page+1}/{total_pages if total_pages > 0 else 1})</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
    
    buttons = []
    
    if not sliced_data:
        msg += "<i>⚠️ Belum ada riwayat pembelian layanan.</i>\n"
    else:
        # Kamus Terjemahan Bulan & Hari ke Bahasa Indonesia
        hari_dict = {0: "Senin", 1: "Selasa", 2: "Rabu", 3: "Kamis", 4: "Jumat", 5: "Sabtu", 6: "Minggu"}
        bulan_dict = {"01": "Januari", "02": "Februari", "03": "Maret", "04": "April", "05": "Mei", "06": "Juni", "07": "Juli", "08": "Agustus", "09": "September", "10": "Oktober", "11": "November", "12": "Desember"}

        for idx, row in enumerate(sliced_data):
            trx_id, tipe, jml, sts, tgl, ket = row
            icon = "🟢" if sts == 'SUCCESS' else ("🔴")
            nomor_urut = start + idx + 1
            
            # --- 1. PECAH DATA TANGGAL & WAKTU ---
            try:
                tgl_str = str(tgl).split('.')[0]
                dt_obj = datetime.datetime.strptime(tgl_str, "%Y-%m-%d %H:%M:%S")
                
                tahun = dt_obj.strftime("%Y")
                bulan_num = dt_obj.strftime("%m")
                tanggal = dt_obj.strftime("%d")
                jam = dt_obj.strftime("%H:%M:%S")
                
                nama_hari = hari_dict.get(dt_obj.weekday(), "")
                nama_bulan = bulan_dict.get(bulan_num, "")
                
                str_bulan = f"{bulan_num} ({nama_bulan})"
                str_tanggal = f"{tanggal} ({nama_hari})"
            except:
                tahun, str_bulan, str_tanggal, jam = "-", "-", "-", "-"
            
            # --- 2. PECAH DATA KETERANGAN (AKUN & UUID/PASS) ---
            nama_paket = ket.split('|')[0].strip()
            
            username = "Unknown"
            akun_match = re.search(r'Akun:\s*([a-zA-Z0-9_]+)', ket, re.IGNORECASE)
            if akun_match: username = akun_match.group(1)

            kunci_label = ""
            kunci_val = ""
            uuid_match = re.search(r'UUID:\s*([^\s\|]+)', ket, re.IGNORECASE)
            pass_match = re.search(r'Pass:\s*([^\s\|]+)', ket, re.IGNORECASE)
            
            if uuid_match:
                kunci_label = "UUID      " # Ditambah spasi agar lurus
                kunci_val = uuid_match.group(1)
            elif pass_match:
                kunci_label = "Password  "
                kunci_val = pass_match.group(1)
            
            # --- 3. SUSUN PESAN TAMPILAN ---
            msg += f"<b>{nomor_urut}. {icon} {nama_paket}</b>\n"
            msg += f"Nama Akun : <code>{username}</code>\n"
            if kunci_val:
                msg += f"{kunci_label}: <code>{kunci_val}</code>\n"
            msg += f"Harga     : Rp {jml:,}\n"
            msg += f"Tahun     : {tahun}\n"
            msg += f"Bulan     : {str_bulan}\n"
            msg += f"Tanggal   : {str_tanggal}\n"
            msg += f"Jam       : {jam}\n"
            msg += "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            
            # --- 4. BUAT TOMBOL DETAIL ---
            nama_paket_bersih = nama_paket.replace("Beli ", "").strip()
            nama_tombol = nama_paket_bersih[:20] + "..." if len(nama_paket_bersih) > 20 else nama_paket_bersih
            buttons.append([Button.inline(f"🔍 {nomor_urut}. Detail: {nama_tombol}", data=f"trxDet_{trx_id}")])

    # Tombol Navigasi Pagination
    nav_buttons = []
    if page > 0:
        nav_buttons.append(Button.inline("⏪ Prev", data=f"riwayat_beli_{page-1}"))
    if page < total_pages - 1:
        nav_buttons.append(Button.inline("Next ⏩", data=f"riwayat_beli_{page+1}"))
        
    if nav_buttons:
        buttons.append(nav_buttons)
        
    buttons.append([Button.inline("🔙 KEMBALI KE MENU", data="riwayat")])

    await event.edit(msg, buttons=buttons, parse_mode='html')

# =================================================================
# TAMPILAN RIWAYAT TOPUP (FORMAT DISAMAKAN DENGAN PEMBELIAN)
# =================================================================
@bot.on(events.CallbackQuery(data=b'riwayat_topup'))
async def history_topup_handler(event):
    import datetime
    
    user_id = event.sender_id
    # Ambil data riwayat yang cukup banyak untuk difilter
    data_trx = database.get_riwayat(user_id, limit=30) 
    
    riwayat_topup = []
    if data_trx:
        for row in data_trx:
            trx_id, tipe, jml, sts, tgl, ket = row
            ket_lower = str(ket).lower()
            # Filter kategori topup/deposit saja
            if any(x in ket_lower for x in ["deposit", "topup", "tambah"]):
                riwayat_topup.append(row)
                
    msg = "<b>💳 RIWAYAT TOP UP SALDO</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
    
    if not riwayat_topup:
        msg += "<i>⚠️ Belum ada riwayat deposit saldo.</i>\n"
    else:
        # Kamus Bahasa Indonesia untuk penamaan hari dan bulan
        hari_dict = {0: "Senin", 1: "Selasa", 2: "Rabu", 3: "Kamis", 4: "Jumat", 5: "Sabtu", 6: "Minggu"}
        bulan_dict = {"01": "Januari", "02": "Februari", "03": "Maret", "04": "April", "05": "Mei", "06": "Juni", "07": "Juli", "08": "Agustus", "09": "September", "10": "Oktober", "11": "November", "12": "Desember"}

        # Kita tampilkan maksimal 10 riwayat agar rapi di layar
        for idx, row in enumerate(riwayat_topup[:10]):
            trx_id, tipe, jml, sts, tgl, ket = row
            
            # Icon Status: Sukses (🟢), Pending (🟡), Gagal (🔴)
            if sts == 'SUCCESS': icon = "🟢"
            elif sts == 'PENDING': icon = "🟡"
            else: icon = "🔴"
            
            nomor_urut = idx + 1
            
            # --- PROSES PECAH DATA WAKTU ---
            try:
                tgl_str = str(tgl).split('.')[0]
                dt_obj = datetime.datetime.strptime(tgl_str, "%Y-%m-%d %H:%M:%S")
                
                tahun   = dt_obj.strftime("%Y")
                bulan_n = dt_obj.strftime("%m")
                tanggal = dt_obj.strftime("%d")
                jam     = dt_obj.strftime("%H:%M:%S")
                
                nama_hari  = hari_dict.get(dt_obj.weekday(), "")
                nama_bulan = bulan_dict.get(bulan_n, "")
                
                str_bulan   = f"{bulan_n} ({nama_bulan})"
                str_tanggal = f"{tanggal} ({nama_hari})"
            except:
                tahun, str_bulan, str_tanggal, jam = "-", "-", "-", "-"
            
            # Bersihkan teks keterangan metode agar tidak terlalu panjang
            metode = ket.replace("Deposit via ", "").replace("Deposit ", "").strip()
            
            # --- SUSUN TAMPILAN SESUAI FORMAT PEMBELIAN ---
            msg += f"<b>{nomor_urut}. {icon} TOP UP SALDO</b>\n"
            msg += f"ID Transaksi : <code>{trx_id}</code>\n"
            msg += f"Metode       : <code>{metode}</code>\n"
            msg += f"Nominal      : Rp {jml:,}\n"
            msg += f"Tahun        : {tahun}\n"
            msg += f"Bulan        : {str_bulan}\n"
            msg += f"Tanggal      : {str_tanggal}\n"
            msg += f"Jam          : {jam}\n"
            msg += "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            
    await event.edit(msg, buttons=[[Button.inline("🔙 KEMBALI KE MENU", data="riwayat")]], parse_mode='html')

# =================================================================
# HANDLER STRUK DETAIL TRANSAKSI (KHUSUS RIWAYAT USER)
# =================================================================
@bot.on(events.CallbackQuery(pattern=b"trxDet_(.*)"))
async def detail_trx_handler(event):
    try:
        import json
        import base64
        
        trx_id = event.pattern_match.group(1).decode()
        user_id = event.sender_id
        
        # 1. Ambil data transaksi dari database
        data_trx = database.get_riwayat(user_id, limit=100)
        detail_row = None
        if data_trx:
            for row in data_trx:
                if str(row[0]) == str(trx_id):
                    detail_row = row
                    break
                    
        if not detail_row:
            return await event.answer("❌ Data transaksi tidak ditemukan.", alert=True)
            
        trx_id_db, tipe, jml, sts, tgl, ket = detail_row
        
        # --- UBAH TAMPILAN STATUS ---
        if sts == 'SUCCESS': 
            icon_sts = "✅ SUCCESS"
        elif sts == 'DELETED': 
            icon_sts = "🗑️ DELETED (Sudah Dihapus)"
        else: 
            icon_sts = "⏳ PENDING"
        
        # --- EKSTRAK USERNAME, PASSWORD & UUID DARI KETERANGAN ---
        username = "Unknown"
        akun_match = re.search(r'Akun:\s*([a-zA-Z0-9_]+)', ket, re.IGNORECASE)
        if akun_match: username = akun_match.group(1)
            
        password = "[Tidak Tersimpan]"
        pass_match = re.search(r'Pass:\s*([^\s\|]+)', ket, re.IGNORECASE)
        if pass_match: password = pass_match.group(1)
            
        uuid_val = "[Tidak Tersimpan]"
        uuid_match = re.search(r'UUID:\s*([^\s\|]+)', ket, re.IGNORECASE)
        if uuid_match: uuid_val = uuid_match.group(1)
            
        # --- TENTUKAN DOMAIN BERDASARKAN SERVER YANG DIPILIH ---
        domain = "Premium Server"
        if "SG 1" in ket: domain = "sg1.singgahvpn.web.id"
        elif "SG 2" in ket: domain = "sg2.singgahvpn.web.id"
        elif "SG 3" in ket: domain = "sg3.singgahvpn.web.id"
        else:
            try: domain = get_var_value("DOMAIN") or "Premium Server"
            except: pass

        msg = ""
        
        # --- 1. JIKA INI ADALAH TRANSAKSI SSH ---
        if "SSH" in ket.upper():
            msg = f"""
<code>========================================
 RIWAYAT AKUN SSH PREMIUM
========================================

 INFORMASI AKUN
Username: {username}
Domain: {domain}
Password: {password}
SSH WS: 80
SSH SSL WS: 443

 FORMAT KONEKSI
WS Format: {domain}:80@{username}:{password}
TLS Format: {domain}:443@{username}:{password}
UDP Format: {domain}:1-65535@{username}:{password}

 INFORMASI TRANSAKSI
ID Trx : {trx_id_db}
Tanggal: {str(tgl).split('.')[0]}
Harga  : Rp {jml:,}
Status : {icon_sts}
========================================</code>
"""
        # --- 2. JIKA INI ADALAH TRANSAKSI XRAY (VMESS/VLESS/TROJAN) ---
        elif any(x in ket.upper() for x in ["VMESS", "VLESS", "TROJAN"]):
            jenis = "VMESS" if "VMESS" in ket.upper() else ("VLESS" if "VLESS" in ket.upper() else "TROJAN")
            
            # Tentukan Kunci Utama (UUID atau Password)
            kunci = uuid_val if jenis in ["VMESS", "VLESS"] else password
            
            if kunci == "[Tidak Tersimpan]":
                kunci_display = "<i>[Tidak tersimpan di versi lama]</i>"
                links_text = "<i>(Link Config tidak bisa dirakit karena UUID/Password tidak tersimpan pada riwayat transaksi versi lama ini).</i>"
            else:
                kunci_display = f"<code>{kunci}</code>"
                
                # --- RAKIT ULANG LINK CONFIG ---
                if jenis == "VMESS":
                    j_tls = {"v":"2","ps":f"{username}-TLS","add":domain,"port":"443","id":kunci,"aid":"0","scy":"auto","net":"ws","type":"none","host":domain,"path":"/vmess","tls":"tls","sni":domain}
                    j_nontls = {"v":"2","ps":f"{username}-NTLS","add":domain,"port":"80","id":kunci,"aid":"0","scy":"auto","net":"ws","type":"none","host":domain,"path":"/vmess","tls":"","sni":""}
                    j_grpc = {"v":"2","ps":f"{username}-GRPC","add":domain,"port":"443","id":kunci,"aid":"0","scy":"auto","net":"grpc","type":"none","host":domain,"path":"vmess-grpc","tls":"tls","sni":domain,"serviceName":"vmess-grpc"}
                    
                    link_tls = "vmess://" + base64.b64encode(json.dumps(j_tls).encode()).decode()
                    link_ntls = "vmess://" + base64.b64encode(json.dumps(j_nontls).encode()).decode()
                    link_grpc = "vmess://" + base64.b64encode(json.dumps(j_grpc).encode()).decode()
                    
                    links_text = f"<b>👇LINK TLS (WS)👇</b>\n<code>{link_tls}</code>\n\n<b>👇LINK NON-TLS (WS)👇</b>\n<code>{link_ntls}</code>\n\n<b>👇LINK GRPC👇</b>\n<code>{link_grpc}</code>"
                
                elif jenis == "VLESS":
                    link_tls = f"vless://{kunci}@{domain}:443?path=/vless&security=tls&encryption=none&type=ws#{username}-TLS"
                    link_nontls = f"vless://{kunci}@{domain}:80?path=/vless&security=none&encryption=none&type=ws#{username}-NTLS"
                    link_grpc = f"vless://{kunci}@{domain}:443?mode=gun&security=tls&encryption=none&type=grpc&serviceName=vless-grpc#{username}-GRPC"
                    
                    links_text = f"<b>👇LINK TLS (WS)👇</b>\n<code>{link_tls}</code>\n\n<b>👇LINK NON-TLS (WS)👇</b>\n<code>{link_nontls}</code>\n\n<b>👇LINK GRPC👇</b>\n<code>{link_grpc}</code>"
                    
                elif jenis == "TROJAN":
                    link_ws = f"trojan://{kunci}@{domain}:443?path=/trojan-ws&security=tls&host={domain}&type=ws&sni={domain}#{username}-WS"
                    link_grpc = f"trojan://{kunci}@{domain}:443?mode=gun&security=tls&type=grpc&serviceName=trojan-grpc&sni={domain}#{username}-GRPC"
                    
                    links_text = f"<b>👇LINK TLS (WS)👇</b>\n<code>{link_ws}</code>\n\n<b>👇LINK GRPC👇</b>\n<code>{link_grpc}</code>"

            msg = f"""
<code>========================================
 RIWAYAT AKUN {jenis} PREMIUM
========================================

 INFORMASI AKUN
Username: {username}
Domain: {domain}
{'UUID' if jenis != 'TROJAN' else 'Password'}: {kunci_display}
Port TLS: 443
Port NTLS: 80
Network: WS / GRPC

 FORMAT KONEKSI
========================================</code>
{links_text}
<code>========================================
 INFORMASI TRANSAKSI
ID Trx : {trx_id_db}
Tanggal: {str(tgl).split('.')[0]}
Harga  : Rp {jml:,}
Status : {icon_sts}
========================================</code>
"""
        # --- 3. JIKA TRANSAKSI LAINNYA (Misal Topup) ---
        else:
            msg = f"""
<b>🧾 INVOICE DETAIL TRANSAKSI</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🆔 ID Trx     :</b> <code>{trx_id_db}</code>
<b>📅 Tanggal    :</b> {str(tgl).split('.')[0]}
<b>📦 Item / Ket :</b> 
{ket}

<b>💰 Harga      :</b> Rp {jml:,}
<b>📊 Status     :</b> {icon_sts}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
"""
        # Peringatan untuk transaksi lama (Tidak ada Username)
        if username == "Unknown" and password == "[Tidak Tersimpan]" and uuid_val == "[Tidak Tersimpan]" and any(x in ket.upper() for x in ["SSH", "VMESS", "VLESS", "TROJAN"]):
            msg += "\n<i>⚠️ Username, Password, dan UUID tidak terdeteksi karena ini adalah riwayat transaksi dari versi lama.</i>"

        # --- LOGIKA TOMBOL (SEMBUNYIKAN JIKA SUDAH DIHAPUS) ---
        buttons = []
        if any(x in ket.upper() for x in ["SSH", "VMESS", "VLESS", "TROJAN"]):
            # Tombol hapus HANYA muncul jika statusnya BUKAN DELETED
            if sts != 'DELETED':
                buttons.append([Button.inline("🗑️ HAPUS AKUN INI", data=f"delMyAcc_{trx_id}")])
            
        buttons.append([Button.inline("🔙 KEMBALI KE RIWAYAT", data="riwayat_beli_0")])
        
        await event.edit(msg, buttons=buttons, parse_mode='html')
        
    except Exception as e:
        await event.answer(f"Error: {e}", alert=True)

# =================================================================
# HANDLER HAPUS AKUN SENDIRI DARI RIWAYAT (DENGAN FALLBACK DATA LAMA)
# =================================================================
@bot.on(events.CallbackQuery(pattern=b"delMyAcc_(.*)"))
async def delete_my_account_handler(event):
    try:
        trx_id = event.pattern_match.group(1).decode()
        user_id = event.sender_id
        chat = event.chat_id
        
        # 1. Ambil data dari database
        data_trx = database.get_riwayat(user_id, limit=100)
        detail_row = None
        if data_trx:
            for row in data_trx:
                if str(row[0]) == str(trx_id):
                    detail_row = row
                    break
                    
        if not detail_row: 
            return await event.answer("❌ Data transaksi tidak ditemukan.", alert=True)
            
        ket = detail_row[5]

        # 2. Ekstrak Username
        username = "Unknown"
        akun_match = re.search(r'Akun:\s*([a-zA-Z0-9_]+)', ket, re.IGNORECASE)
        if akun_match: 
            username = akun_match.group(1)

        # --- 3. JIKA TRANSAKSI LAMA (TIDAK ADA USERNAME), MINTA INPUT MANUAL ---
        is_manual_input = False
        if username == "Unknown":
            await event.answer("⚠️ Memulai mode hapus manual...", alert=False)
            try:
                async with bot.conversation(chat, timeout=60) as conv:
                    # Bot akan mengirim pesan peringatan dan meminta ketik nama manual
                    pesan_tanya = await conv.send_message("⚠️ <b>Sistem Lama Terdeteksi</b>\nBot tidak menyimpan username pada riwayat transaksi ini.\n\nSilakan <b>ketik manual Username</b> akun yang ingin dihapus:\n<i>(Ketik /cancel untuk batal)</i>", parse_mode='html')
                    
                    # Bot menunggu balasan ketikan dari user
                    resp = await conv.wait_event(events.NewMessage(incoming=True, from_users=user_id))
                    
                    if resp.raw_text.strip().lower() == '/cancel':
                        await pesan_tanya.delete()
                        return await conv.send_message("❌ Proses hapus dibatalkan.")
                        
                    # Menangkap nama yang diketik user
                    username = resp.raw_text.strip().replace(" ", "")
                    is_manual_input = True
                    await pesan_tanya.delete() # Bersihkan chat agar rapi
            except AlreadyInConversationError:
                return await event.respond("⚠️ Anda masih dalam proses. Selesaikan yang sebelumnya atau ketik /cancel.")
            except asyncio.TimeoutError:
                return await event.respond("❌ Waktu habis.")

        # 4. Tentukan Server Target
        if "SG 1" in ket:
            tipe_server = "sg1"; ip, pw = "165.245.182.117", "Singgahvpn-18-November"
        elif "SG 2" in ket:
            tipe_server = "sg2"; ip, pw = "68.183.191.42", "Singgahvpn-11-December"
        elif "SG 3" in ket:
            tipe_server = "sg3"; ip, pw = "143.198.80.108", "Singgahvpn-02-November"
        else:
            tipe_server = "pusat"

        # 5. Tentukan Command
        if "SSH" in ket.upper():
            cmd = f"userdel -f {username} && sed -i '/^{username} hard/d' /etc/security/limits.conf && if [ -f '/etc/zivpn/user-db.json' ]; then jq --arg u '{username}' '.auth.config -= [$u] | del(.[$u])' /etc/zivpn/user-db.json > /tmp/db && mv /tmp/db /etc/zivpn/user-db.json; fi && systemctl restart zivpn"
        elif "VMESS" in ket.upper():
            cmd = f'printf "%s\\n" "{username}" | bot-delws'
        elif "VLESS" in ket.upper():
            cmd = f'printf "%s\\n" "{username}" | bot-delvless'
        elif "TROJAN" in ket.upper():
            cmd = f'printf "%s\\n" "{username}" | bot-deltr'
        else:
            return await event.answer("⚠️ Tipe layanan ini tidak mendukung hapus otomatis.", alert=True)

        # 6. Eksekusi Penghapusan
        teks_tunggu = f"⏳ <b>Sedang menghapus akun <code>{username}</code> dari server {tipe_server.upper()}...</b>"
        
        if is_manual_input:
            msg_wait = await event.respond(teks_tunggu, parse_mode='html')
        else:
            msg_wait = await event.edit(teks_tunggu, parse_mode='html')

        try:
            if tipe_server == "pusat":
                subprocess.run(cmd, shell=True)
            else:
                ssh_client = paramiko.SSHClient()
                ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                ssh_client.connect(hostname=ip, port=22, username="root", password=pw, timeout=15)
                stdin, stdout, stderr = ssh_client.exec_command(cmd)
                stdout.channel.recv_exit_status() 
                ssh_client.close()

            # ---> INI TAMBAHAN BARUNYA: UBAH STATUS DATABASE JADI DELETED <---
            database.mark_trx_deleted(trx_id)

            sukses_msg = f"""
<b>✅ AKUN BERHASIL DIHAPUS!</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>👤 Username :</b> <code>{username}</code>
<b>🌐 Server   :</b> {tipe_server.upper()}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<i>Status transaksi telah diubah menjadi Dihapus.</i>
"""
            await msg_wait.edit(sukses_msg, buttons=[[Button.inline("🔙 KEMBALI KE RIWAYAT", data="riwayat_beli_0")]], parse_mode='html')
        except Exception as err_ssh:
            await msg_wait.edit(f"❌ <b>Gagal koneksi ke VPS:</b>\n{err_ssh}", parse_mode='html')

    except Exception as e:
        await event.respond(f"❌ <b>Terjadi Kesalahan:</b>\n{str(e)}", parse_mode='html')



@bot.on(events.CallbackQuery(data=b'topup'))
async def topup_menu_handler(event):
    if event.sender_id in user_states: del user_states[event.sender_id]
    
    msg = """
<b>💰 PILIH METODE TOPUP</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Silakan pilih metode deposit yang Anda inginkan:

<b>1️⃣ OTOMATIS</b> (Rekomendasi)
• Saldo masuk otomatis dalam hitungan detik.
• Support QRIS Instant (Semua E-Wallet/Bank).
• Minimal Rp 10.000.

<b>2️⃣ MANUAL</b> (Alternatif)
• Transfer manual ke QRIS Admin.
• Wajib kirim bukti transfer ke Admin.
• Saldo diproses manual (Human Process).
"""
    buttons = [
        [Button.inline("⚡ QRIS INSTANT (Otomatis)", data="topup_auto")],
        [Button.inline("🏦 QRIS MANUAL (Chat Admin)", data="topup_manual")],
        [Button.inline("🔙 KEMBALI", data="menu_as_user")]
    ]
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'topup_manual'))
async def topup_manual_handler(event):
    # Set state agar inputan lari ke logic manual
    user_states[event.sender_id] = 'WAIT_MANUAL_NOMINAL'
    
    msg = """
<b>🏦 TOP UP MANUAL (QRIS ADMIN)</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Silakan masukkan <b>NOMINAL</b> yang ingin Anda transfer.
<i>Contoh: 50000</i>

<i>Nanti Anda akan diminta scan QRIS dan kirim bukti ke Admin.</i>
"""
    buttons = [[Button.inline("❌ BATAL", data="topup")]]
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'topup_auto'))
async def topup_auto_handler(event):
    user_states[event.sender_id] = 'WAITING_NOMINAL'
    msg = """
<b>⚡ TOP UP OTOMATIS (QRIS INSTANT)</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Silakan ketik nominal deposit.
🔹 <b>Minimal:</b> Rp 10.000
🔹 <b>Metode:</b> QRIS Instant (Otomatis)
<i>Contoh ketik: 15000</i>
"""
    buttons = [[Button.inline("🔙 BATAL / KEMBALI", data="topup")]]
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'cancel_topup'))
async def cancel_topup_handler(event):
    if event.sender_id in user_states: del user_states[event.sender_id]
    await event.edit("❌ Topup Dibatalkan.", buttons=[[Button.inline("🔙 KEMBALI", data="menu_as_user")]], parse_mode='html')

@bot.on(events.NewMessage(incoming=True))
async def input_nominal_handler(event):
    user_id = event.sender_id
    sender = await event.get_sender()
    username = sender.username if sender.username else "TanpaUsername"
    
    # Cek State: Jika sedang di state Admin, jangan jalankan handler user ini
    if user_id in admin_states:
        return 

    # Ambil State User
    state = user_states.get(user_id)

    if state == 'WAIT_MANUAL_NOMINAL':
        text = event.raw_text.strip().replace(".", "").replace(",", "")
        if not text.isdigit(): return await event.reply("⚠️ Harap masukkan angka saja.")
        
        nominal = int(text)
        if nominal < 10000: return await event.reply("⚠️ Minimal topup Rp 10.000.")
        
        # Hapus State
        del user_states[user_id]
        
        # Ambil Waktu Sekarang
        now = datetime.datetime.now()
        tgl = now.strftime("%d-%m-%Y")
        jam = now.strftime("%H:%M:%S")

        # Path Gambar QRIS
        file_path = '/usr/bin/kyt/modules/qris/qris.jpg'
        
        # --- FORMAT PESAN UNTUK ADMIN ---
        msg_to_admin = f"""Halo Admin, Saya sudah transfer untuk Topup Saldo.

🆔 ID: {user_id}
👤 User: @{username}
💰 Nominal: Rp {nominal:,}
📅 Waktu: {tgl} {jam}

Mohon dicek dan diproses. Berikut bukti transfer saya:"""

        # Encode pesan agar bisa masuk ke Link URL (Khusus WA)
        encoded_msg = urllib.parse.quote(msg_to_admin)
        
        # Link WhatsApp (Bisa Auto Text)
        link_wa = f"https://wa.me/{ADMIN_WA}?text={encoded_msg}"
        
        # Link Telegram (Langsung ke Chat Admin)
        # Karena TG tidak bisa auto-text, user harus copy manual dulu
        link_tg = f"https://t.me/{ADMIN_TG}"

        # --- LANGKAH 1: KIRIM TEKS UTUH KE USER UNTUK DI-COPY ---
        # Menggunakan format <code> agar user bisa tinggal klik untuk copy
        await event.reply(f"📋 <b>KLIK TEKS DI BAWAH UNTUK COPY:</b>\n\n<code>{msg_to_admin}</code>", parse_mode='html')

        # --- LANGKAH 2: KIRIM GAMBAR QRIS DAN TOMBOL ---
        capt = f"""
<b>💸 FORMULIR KONFIRMASI TOPUP</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>💰 Nominal :</b> <code>Rp {nominal:,}</code>
<b>📅 Waktu   :</b> {jam} WIB
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>ℹ️ INSTRUKSI:</b>
1. Transfer sesuai nominal.
2. <b>Copy</b> teks di atas (klik teksnya).
3. Klik tombol <b>KONFIRMASI KE TG</b>.
4. <b>Paste</b> teks tadi ke chat Admin & kirim bukti transfer.
"""
        buttons = [
            [Button.url("🟢 KONFIRMASI KE WA", link_wa)],
            [Button.url("🔵 KONFIRMASI KE TG", link_tg)],
            [Button.inline("🔙 KEMBALI MENU", data="menu_as_user")]
        ]

        if os.path.exists(file_path):
            await event.reply(capt, file=file_path, buttons=buttons, parse_mode='html')
        else:
            await event.reply(f"⚠️ <b>Error:</b> File QRIS tidak ditemukan.\n\n{capt}", buttons=buttons, parse_mode='html')

    # =================================================================
    # LOGIKA 2: TOPUP OTOMATIS (RAMASHOP QRIS)
    # =================================================================
    elif state == 'WAITING_NOMINAL':
        text = event.raw_text.strip()
        if not text.isdigit(): return await event.reply("⚠️ Harap masukkan angka saja.")
        
        nominal = int(text)
        if nominal < 10000: return await event.reply("⚠️ Minimal deposit Rp 10.000.")
        
        del user_states[user_id]
        msg_wait = await event.reply("🔄 <b>Sedang membuat tagihan QRIS...</b>", parse_mode='html')
        
        try:
            reff_id = f"DEP{random.randint(10000000, 99999999)}"
            res = atlantic.create_deposit(reff_id, nominal, "qris", "qris")
            
            if res.get('status') == True or res.get('success') == True:
                data = res['data']
                at_id = data.get('depositId', '0')
                total_bayar = data.get('totalAmount', nominal)
                qr_string = data.get('qrString') # Kita ambil string mentahnya
                expired = data.get('expiredAt', '-')
                
                database.new_deposit(user_id, reff_id, nominal, at_id, "qris")
                
                capt = f"""
<b>✅ TAGIHAN QRIS INSTANT</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🆔 Deposit ID:</b> <code>{at_id}</code>
<b>💰 Total Bayar:</b> <code>Rp {total_bayar:,}</code>
<b>⏳ Expired:</b> {expired}

⚠️ <i>Mohon transfer <b>TEPAT SESUAI NOMINAL</b> (Hingga 3 digit terakhir). Saldo masuk otomatis.</i>
<i>Klik tombol <b>CEK STATUS</b> jika sudah transfer.</i>
"""
                buttons_qris = [
                    [Button.inline("🔄 CEK STATUS PEMBAYARAN", data=f"cek_status_{at_id}_{reff_id}")],
                    [Button.inline("🔙 BATAL / KEMBALI", data="menu_as_user")]
                ]

                try:
                    # Kita rakit ulang link-nya dengan tambahan format=jpeg agar asli berupa gambar
                    encoded_qr = urllib.parse.quote(qr_string)
                    gen_url = f"https://api.qrserver.com/v1/create-qr-code/?size=500x500&format=jpeg&margin=20&data={encoded_qr}"
                    
                    # Waktu tunggu diperpanjang jadi 10 detik agar tidak gagal download
                    req = requests.get(gen_url, timeout=10)
                    
                    if req.status_code == 200:
                        foto_qris = io.BytesIO(req.content)
                        foto_qris.name = "qris.jpeg" # Beri ekstensi jpeg
                        
                        # force_document=False memaksa Telegram menampilkan sebagai FOTO
                        await event.client.send_file(
                            event.chat_id, 
                            file=foto_qris, 
                            caption=capt, 
                            buttons=buttons_qris, 
                            parse_mode='html',
                            force_document=False
                        )
                        await msg_wait.delete()
                    else:
                        raise Exception("Gagal download dari server QR")
                except Exception as e:
                    # Ini hanya akan muncul jika server QR sedang down
                    qr_fallback = data.get('qrImage')
                    await msg_wait.edit(f"{capt}\n\n<b>Link QR Code:</b>\n{qr_fallback}", buttons=buttons_qris, parse_mode='html')
            else:
                pesan_error = res.get('message', 'Unknown Error')
                await msg_wait.edit(f"❌ <b>Gagal Membuat Tagihan:</b>\n{pesan_error}", buttons=[[Button.inline("🔙 KEMBALI", data="menu_as_user")]], parse_mode='html')
        except Exception as e:
            await msg_wait.edit(f"❌ <b>System Error:</b> {str(e)}")
            
# ==========================================
# HANDLER CEK IP TERDAFTAR (READ ONLY)
# ==========================================
@bot.on(events.CallbackQuery(data=b'regis'))
async def view_registered_ips(event):
    # 1. Validasi Admin
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true":
            return await event.answer("❌ Akses Ditolak!", alert=True)
    except:
        pass 

    # 2. Loading Animation (Toast)
    await event.answer("🔄 Mengambil data dari GitHub...", alert=False)

    # 3. Link RAW GitHub (Sesuai Script VPS Anda)
    url_ijin = "https://github.com/Anggabayuwijaya599/ijin/raw/refs/heads/main/ipvps"
    
    try:
        # Ambil data dari internet (Curl)
        r = requests.get(url_ijin)
        
        if r.status_code != 200:
            return await event.edit(f"❌ Gagal koneksi ke GitHub. Code: {r.status_code}", buttons=[[Button.inline("🔙 Kembali", data="menu")]])
        
        content = r.text
        lines = content.splitlines()
        
        # 4. Parsing Data
        # Format di file: ### username exp_date ip status
        
        msg = "<b>📝 DAFTAR IP PREMIUM TERDAFTAR</b>\n"
        msg += "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        
        total_ip = 0
        
        for line in lines:
            parts = line.strip().split()
            # Kita cek apakah baris ini valid (minimal ada 4-5 kolom & diawali ###)
            # Sesuai contoh: ### haniefautophile 2050-02-02 157.245.159.230 ON
            if len(parts) >= 4 and "###" in parts[0]:
                username = parts[1]
                exp_date = parts[2]
                ip_addr = parts[3]
                status = parts[4] if len(parts) > 4 else "Unknown"
                
                # Format Tampilan per User
                msg += f"👤 <b>{username}</b>\n"
                msg += f"├ 📡 IP : <code>{ip_addr}</code>\n"
                msg += f"├ 📅 Exp: {exp_date}\n"
                msg += f"└ 🔋 Sts: {status}\n\n"
                total_ip += 1
                
        if total_ip == 0:
            msg += "<i>⚠️ Tidak ada data IP ditemukan.</i>"
        else:
            msg += f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n<i>Total Terdaftar: {total_ip} IP</i>"
            
        # 5. Tombol Kembali
        buttons = [[Button.inline("🔙 KEMBALI MENU", data="menu")]]
        
        await event.edit(msg, buttons=buttons, parse_mode='html')
        
    except Exception as e:
        await event.edit(f"❌ <b>Error System:</b> {str(e)}", buttons=[[Button.inline("🔙 MENU", data="menu")]], parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b'cek_status_'))
async def check_status_trx_handler(event):
    try:
        parts = event.data.decode('utf-8').split('_')
        at_id = parts[2]
        reff_id = parts[3]
        user_id = event.sender_id
        
        print(f"\n[CEK STATUS] User {user_id} mengecek transaksi {at_id}")
        
        # Ambil data dari database lokal
        local_status, local_amount = database.get_trx_status(reff_id)
        if local_status == 'SUCCESS':
            return await event.answer("✅ Pembayaran ini SUDAH SUKSES!", alert=True)
            
        # Panggil API Ramashop
        res = atlantic.check_status(at_id)
        print(f"[CEK STATUS] Response API: {res}")
        
        # Pastikan response API valid (Ramashop menggunakan status=true)
        if res.get('status') == True or res.get('success') == True:
            data = res.get('data', {})
            status_atl = data.get('status') 
            
            # Jika status "success" atau "already" (sudah diproses oleh pusat)
            if status_atl == 'success' or status_atl == 'already':
                nominal_masuk = int(data.get('paidAmount', local_amount))
                
                if nominal_masuk <= 0:
                    nominal_masuk = local_amount
                
                # Eksekusi Tambah Saldo
                database.update_trx_success(reff_id)
                database.tambah_saldo(user_id, nominal_masuk, "Deposit Otomatis QRIS")
                
                print(f"[CEK STATUS] SUKSES! Saldo ditambah: {nominal_masuk}")
                await event.edit(f"""
<b>✅ PEMBAYARAN BERHASIL!</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🆔 Reff ID:</b> <code>{reff_id}</code>
<b>💰 Saldo Masuk:</b> <code>Rp {nominal_masuk:,}</code>

<i>Terima kasih! Saldo telah ditambahkan ke akun Anda.</i>
""", buttons=[[Button.inline("🔙 KEMBALI KE MENU", data="menu_as_user")]], parse_mode='html')

            # Jika masih menunggu pembayaran
            elif status_atl == 'pending':
                print("[CEK STATUS] Masih Pending.")
                await event.answer("⏳ STATUS: PENDING\nSistem belum menemukan pembayaran Anda. Pastikan nominal transfer sesuai.", alert=True)
                
            # Jika kadaluarsa atau dibatalkan
            elif status_atl in ['expired', 'failed']:
                print("[CEK STATUS] Expired/Failed.")
                await event.edit(f"❌ <b>TRANSAKSI GAGAL/EXPIRED</b>\nWaktu pembayaran habis, silakan buat tagihan baru.", buttons=[[Button.inline("🔙 KEMBALI", data="menu_as_user")]], parse_mode='html')
            
            else:
                await event.answer(f"Status Server: {status_atl}", alert=True)
        else:
            pesan_err = res.get('message', 'Unknown Error Response')
            print(f"[CEK STATUS] ERROR API: {pesan_err}")
            await event.answer(f"❌ Gagal Cek: {pesan_err}", alert=True)
            
    except Exception as e:
        print(f"[CEK STATUS] EXCEPTION: {e}")
        await event.answer(f"Error System: {str(e)}", alert=True)
        
def load_wd_data():
    if not os.path.exists(WD_FILE): return []
    try:
        with open(WD_FILE, 'r') as f: return json.load(f)
    except: return []

def save_wd_data(data):
    with open(WD_FILE, 'w') as f: json.dump(data, f, indent=4)

# 1. MENU UTAMA WITHDRAW
@bot.on(events.CallbackQuery(data=b'adm_wd_start'))
async def wd_menu_start(event):
    sender_id = event.sender_id
    if valid(str(sender_id)) != "true": return
    
    # Reset State
    if sender_id in admin_states: del admin_states[sender_id]
    
    msg = """
<b>💸 WITHDRAW CENTER</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Silakan pilih metode pencairan saldo Atlantic:

<b>📂 DATA TERSIMPAN</b>
Gunakan data rekening yang sudah didaftarkan.

<b>🏧 INPUT MANUAL</b>
Input kode bank dan nomor rekening manual.

<b>➕ TAMBAH DATA</b>
Daftarkan rekening baru ke database.

<b>🗑️ HAPUS DATA</b>
Hapus rekening yang tersimpan.
"""
    buttons = [
        [Button.inline("📂 PILIH TUJUAN TERSIMPAN", data="wd_pick_saved")],
        [Button.inline("🏧 INPUT MANUAL", data="wd_manual_input")],
        [Button.inline("➕ TAMBAH REKENING BARU", data="wd_add_new")],
        [Button.inline("🗑️ HAPUS REKENING", data="wd_delete_menu")], # Tombol Baru
        [Button.inline("🔙 KEMBALI", data="menu")]
    ]
    await event.edit(msg, buttons=buttons, parse_mode='html')

# 2. HANDLER LIST DATA TERSIMPAN (PILIH)
@bot.on(events.CallbackQuery(data=b'wd_pick_saved'))
async def wd_pick_handler(event):
    data_wd = load_wd_data()
    
    if not data_wd:
        return await event.answer("⚠️ Belum ada data rekening tersimpan.", alert=True)
    
    msg = "<b>📂 PILIH REKENING TUJUAN:</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n<i>Klik pada nama untuk withdraw ke akun tersebut.</i>"
    buttons = []
    
    for idx, item in enumerate(data_wd):
        # Format: [BCA] Alias
        label = f"[{item['bank']}] {item['alias']}"
        buttons.append([Button.inline(label, data=f"wd_exec_{idx}")])
    
    buttons.append([Button.inline("🔙 KEMBALI", data="adm_wd_start")])
    await event.edit(msg, buttons=buttons, parse_mode='html')

# 3. HANDLER MENU HAPUS (DELETE)
@bot.on(events.CallbackQuery(data=b'wd_delete_menu'))
async def wd_delete_menu_handler(event):
    data_wd = load_wd_data()
    
    if not data_wd:
        return await event.answer("⚠️ Data kosong, tidak ada yang bisa dihapus.", alert=True)
    
    msg = "<b>🗑️ HAPUS DATA REKENING</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n<i>Klik pada nama rekening untuk <b>MENGHAPUSNYA</b> secara permanen.</i>"
    buttons = []
    
    for idx, item in enumerate(data_wd):
        # Format Tombol Merah (Visual Hapus)
        label = f"❌ HAPUS: {item['alias']} ({item['bank']})"
        buttons.append([Button.inline(label, data=f"wd_del_exec_{idx}")])
    
    buttons.append([Button.inline("🔙 KEMBALI", data="adm_wd_start")])
    await event.edit(msg, buttons=buttons, parse_mode='html')

# 4. EKSEKUSI HAPUS DATA
@bot.on(events.CallbackQuery(pattern=b'wd_del_exec_'))
async def wd_delete_exec_handler(event):
    try:
        idx = int(event.data.decode('utf-8').split('_')[3])
        data_wd = load_wd_data()
        
        if 0 <= idx < len(data_wd):
            removed = data_wd.pop(idx) # Hapus item dari list
            save_wd_data(data_wd) # Simpan perubahan
            await event.answer(f"✅ Data '{removed['alias']}' berhasil dihapus!", alert=True)
        else:
            await event.answer("❌ Data sudah tidak ada.", alert=True)
        
        # Refresh tampilan menu hapus
        await wd_delete_menu_handler(event)
        
    except Exception as e:
        await event.answer(f"Error: {e}", alert=True)

# 5. HANDLER INPUT MANUAL (Start)
@bot.on(events.CallbackQuery(data=b'wd_manual_input'))
async def wd_manual_handler(event):
    sender_id = event.sender_id
    admin_states[sender_id] = 'WD_WAIT_BANK'
    await event.edit("<b>🏧 INPUT MANUAL</b>\n\nMasukkan <b>KODE BANK / E-WALLET</b>\nContoh: <code>BNI</code>, <code>DANA</code>, <code>OVO</code>", parse_mode='html', buttons=[[Button.inline("❌ BATAL", data="adm_wd_start")]])

# 6. HANDLER TAMBAH DATA BARU (Start)
@bot.on(events.CallbackQuery(data=b'wd_add_new'))
async def wd_add_handler(event):
    sender_id = event.sender_id
    admin_states[sender_id] = 'ADDWD_BANK'
    await event.edit("<b>➕ TAMBAH DATABASE REKENING</b>\n\nMasukkan <b>KODE BANK / E-WALLET</b>\nContoh: <code>BCA</code>, <code>DANA</code>, <code>GOPAY</code>", parse_mode='html', buttons=[[Button.inline("❌ BATAL", data="adm_wd_start")]])

# 7. EKSEKUSI DARI LIST TERSIMPAN (WITHDRAW)
@bot.on(events.CallbackQuery(pattern=b'wd_exec_'))
async def wd_exec_saved_handler(event):
    sender_id = event.sender_id
    try:
        idx = int(event.data.decode('utf-8').split('_')[2])
        data_wd = load_wd_data()
        
        # Cek jika index valid
        if idx >= len(data_wd):
            return await event.answer("⚠️ Data tidak ditemukan (mungkin sudah dihapus).", alert=True)

        selected = data_wd[idx]
        
        # Simpan ke Context langsung lompat ke Nominal
        admin_context[sender_id] = {
            'kode_bank': selected['bank'],
            'nomor_akun': selected['rek'],
            'nama_pemilik': selected['nama']
        }
        admin_states[sender_id] = 'WD_WAIT_NOMINAL'
        
        msg = f"""
<b>✅ DATA TERPILIH</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🏦 Bank :</b> {selected['bank']}
<b>👤 Nama :</b> {selected['nama']}
<b>🔢 No   :</b> {selected['rek']}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>Silakan Masukkan NOMINAL Withdraw:</b>
<i>(Angka saja, contoh: 100000)</i>
"""
        await event.edit(msg, buttons=[[Button.inline("❌ BATAL", data="adm_wd_start")]], parse_mode='html')
        
    except Exception as e:
        await event.answer(f"Error: {e}", alert=True)

# 8. LOGIKA INPUT TEXT (State Machine Gabungan)
@bot.on(events.NewMessage(incoming=True))
async def wd_global_input_handler(event):
    user_id = event.sender_id
    if user_id not in admin_states: return
    
    state = admin_states[user_id]
    text = event.raw_text.strip()
    
    # === BAGIAN 1: PROSES TAMBAH DATA (ADDWD) ===
    if state == 'ADDWD_BANK':
        admin_context[user_id] = {'bank': text.upper()}
        admin_states[user_id] = 'ADDWD_REK'
        await event.reply(f"✅ Bank: <b>{text.upper()}</b>\n\nMasukkan <b>NOMOR REKENING / HP</b>:", parse_mode='html')

    elif state == 'ADDWD_REK':
        admin_context[user_id]['rek'] = text
        admin_states[user_id] = 'ADDWD_NAMA'
        await event.reply("Masukkan <b>NAMA PEMILIK</b> rekening:", parse_mode='html')

    elif state == 'ADDWD_NAMA':
        admin_context[user_id]['nama'] = text
        admin_states[user_id] = 'ADDWD_ALIAS'
        await event.reply("Masukkan <b>NAMA PANGGILAN / ALIAS</b> (Untuk tombol):\nContoh: <i>BCA Admin, Dana Cadangan</i>", parse_mode='html')

    elif state == 'ADDWD_ALIAS':
        ctx = admin_context[user_id]
        new_data = {
            'bank': ctx['bank'],
            'rek': ctx['rek'],
            'nama': ctx['nama'],
            'alias': text
        }
        
        current_data = load_wd_data()
        current_data.append(new_data)
        save_wd_data(current_data)
        
        del admin_states[user_id]
        del admin_context[user_id]
        
        await event.reply(f"✅ <b>DATA BERHASIL DISIMPAN!</b>\n\nSekarang Anda bisa memilih <b>{text}</b> di menu Withdraw.", buttons=[[Button.inline("🔙 Kembali ke WD", data="adm_wd_start")]], parse_mode='html')

    # === BAGIAN 2: PROSES WITHDRAW MANUAL (WD) ===
    elif state == 'WD_WAIT_BANK':
        admin_context[user_id] = {'kode_bank': text.upper()}
        admin_states[user_id] = 'WD_WAIT_REK'
        await event.reply(f"✅ Bank: <b>{text.upper()}</b>\n\nMasukkan <b>NOMOR REKENING / HP</b> tujuan:", parse_mode='html')
        
    elif state == 'WD_WAIT_REK':
        admin_context[user_id]['nomor_akun'] = text
        admin_states[user_id] = 'WD_WAIT_NAMA'
        await event.reply("Masukkan <b>NAMA PEMILIK</b> rekening:", parse_mode='html')
        
    elif state == 'WD_WAIT_NAMA':
        admin_context[user_id]['nama_pemilik'] = text
        admin_states[user_id] = 'WD_WAIT_NOMINAL'
        await event.reply("Masukkan <b>NOMINAL</b> pencairan (angka saja):", parse_mode='html')
        
    # === BAGIAN 3: EKSEKUSI WITHDRAW (MANUAL & SAVED) ===
    elif state == 'WD_WAIT_NOMINAL':
        if not text.isdigit(): return await event.reply("⚠️ Nominal harus angka!")
        
        ctx = admin_context[user_id]
        nominal = int(text)
        ref_id = f"WD{random.randint(100000, 999999)}"
        
        msg_wait = await event.reply("🔄 <b>Memproses Transfer...</b>", parse_mode='html')
        
        # Eksekusi Transfer ke Atlantic
        res = atlantic.create_transfer(ref_id, ctx['kode_bank'], ctx['nomor_akun'], ctx['nama_pemilik'], nominal)
        
        if res.get('status') == True:
            data = res['data']
            msg_success = f"""
<b>✅ WITHDRAW BERHASIL DIPROSES</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🆔 ID WD      :</b> <code>{data['id']}</code>
<b>🏦 Bank       :</b> <code>{ctx['kode_bank']}</code>
<b>👤 Penerima   :</b> <code>{data['nama']}</code>
<b>🔢 No. Rek    :</b> <code>{data['nomor_tujuan']}</code>
<b>💰 Nominal    :</b> <code>Rp {data['nominal']:,}</code>
<b>💸 Fee        :</b> <code>Rp {data['fee']:,}</code>
<b>📊 Status     :</b> <code>{data['status']}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
"""
            await msg_wait.edit(msg_success, parse_mode='html', buttons=[[Button.inline("🔙 Menu Admin", data="menu")]])
        else:
            err_msg = res.get('message', 'Unknown Error')
            await msg_wait.edit(f"❌ <b>Gagal Withdraw:</b>\n<code>{err_msg}</code>", parse_mode='html', buttons=[[Button.inline("🔙 Coba Lagi", data="adm_wd_start")]])
        
        # Bersihkan State
        del admin_states[user_id]
        del admin_context[user_id]
        
# =================================================================
# HANDLER BROADCAST (SIARAN PESAN)
# =================================================================
@bot.on(events.CallbackQuery(data=b'adm_broadcast_start'))
async def broadcast_start_handler(event):
    sender = await event.get_sender()
    # Validasi Admin
    if valid(str(sender.id)) != "true": 
        return await event.answer("Akses Ditolak", alert=True)

    # Set State Admin
    admin_states[sender.id] = 'WAIT_BROADCAST_MSG'
    
    msg = """
<b>📢 BROADCAST MESSAGE</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Silakan kirim <b>PESAN</b> (Teks, Gambar, atau Sticker) yang ingin disiarkan ke seluruh member bot.

<i>Ketik /cancel untuk membatalkan.</i>
"""
    await event.edit(msg, buttons=[[Button.inline("❌ BATAL", data="cancel_admin_process")]], parse_mode='html')
    
 # =================================================================
# HANDLER MENU PILIH SERVER (UNTUK REMOTE VPS)
# =================================================================
@bot.on(events.CallbackQuery(data=b'server_list'))
async def server_list_handler(event):
    # Cek apakah ini benar-admin
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true":
            return await event.answer("❌ Akses Ditolak!", alert=True)
    except:
        pass

    # Membuat Variabel TXT untuk menampilkan Info 3 VPS
    TXT = "<b>🖥 M A N A G E R  S E R V E R  V P N</b>\n"
    TXT += "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    TXT += "Pilih server yang ingin diremote untuk pembuatan akun (SSH & Xray):\n\n"
    
    buttons = []
    
    # Looping data VPS untuk dimasukkan ke TXT dan Tombol
    for vps_id, data in VPS_SERVERS.items():
        TXT += f"📡 <b>{data['name']}</b>\n"
        TXT += f"├ IP     : <code>{data['ip']}</code>\n"
        TXT += f"└ Domain : <code>{data['domain']}</code>\n\n"
        
        # Tambahkan tombol per-server (contoh data: remote_sg1, remote_sg2)
        buttons.append([Button.inline(f"⚙️ KELOLA {data['name'].upper()}", data=f"remote_{vps_id}")])
        
    TXT += "<i>Silakan pilih server di bawah ini:</i>"
    buttons.append([Button.inline("🔙 KEMBALI KE ADMIN", data="menu")])
    
    await event.edit(TXT, buttons=buttons, parse_mode='html')
    
# =================================================================
# HANDLER PILIH LAYANAN DI MANAGE SERVER (REMOTE VPS ADMIN)
# =================================================================
@bot.on(events.CallbackQuery(pattern=b'remote_(.*)'))
async def remote_server_handler(event):
    sender_id = event.sender_id
    if valid(str(sender_id)) != "true":
        return await event.answer("❌ Akses Ditolak!", alert=True)

    vps_id = event.pattern_match.group(1).decode('utf-8')
    if vps_id not in VPS_SERVERS:
        return await event.answer("⚠️ Server tidak ditemukan di konfigurasi!", alert=True)

    data = VPS_SERVERS[vps_id]

    msg = f"""
<b>⚙️ KELOLA SERVER: {data['name']}</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>📡 IP:</b> <code>{data['ip']}</code>
<b>🌐 Domain:</b> <code>{data['domain']}</code>

<i>Silakan pilih layanan untuk membuat akun (Bypass Saldo / Mode Owner):</i>
"""
    buttons = [
        [Button.inline("☁️ BIKIN SSH", data=f"admcreate_{vps_id}_ssh"), Button.inline("⚡ BIKIN VMESS", data=f"admcreate_{vps_id}_vmess")],
        [Button.inline("🚀 BIKIN VLESS", data=f"admcreate_{vps_id}_vless"), Button.inline("🛡 BIKIN TROJAN", data=f"admcreate_{vps_id}_trojan")],
        [Button.inline("👻 BIKIN SHADOWSOCKS", data=f"admcreate_{vps_id}_ss")],
        [Button.inline("🔙 KEMBALI KE LIST SERVER", data="server_list")]
    ]
    await event.edit(msg, buttons=buttons, parse_mode='html')
    
# =================================================================
# TRIGGER MULAI INPUT PEMBUATAN AKUN OLEH ADMIN
# =================================================================
@bot.on(events.CallbackQuery(pattern=b'admcreate_(.*)_(.*)'))
async def admin_create_start(event):
    sender_id = event.sender_id
    if valid(str(sender_id)) != "true": return

    vps_id = event.pattern_match.group(1).decode('utf-8')
    layanan = event.pattern_match.group(2).decode('utf-8').upper()

    # Set Context & State untuk Admin
    admin_context[sender_id] = {'vps_id': vps_id, 'layanan': layanan}
    admin_states[sender_id] = 'ADM_CREATE_USER'

    msg = f"""
<b>🛠 BIKIN AKUN {layanan} (MODE OWNER)</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>Server Tujuan:</b> {VPS_SERVERS[vps_id]['name']}

Silakan balas pesan ini dengan <b>Username</b> untuk akun baru.
<i>(Tanpa spasi, contoh: owner01)</i>
"""
    await event.edit(msg, buttons=[[Button.inline("❌ BATAL", data=f"remote_{vps_id}")]], parse_mode='html')