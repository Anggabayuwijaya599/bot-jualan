from kyt import *
import subprocess
import asyncio
from telethon import events
from telethon.tl.custom import Button

# // Check Service Info ⚡
@bot.on(events.CallbackQuery(data=b'info'))
async def info_vps(event):
    # Validasi User
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    # Fungsi Internal untuk proses
    async def info_vps_process(event):
        cmd = '/usr/bin/kyt/shell/bot/bot-vps-info'
        
        # --- ANIMASI LOADING ---
        await event.edit("Processing.")
        await asyncio.sleep(0.3)
        await event.edit("`Processing Info Service Server...`")
        await asyncio.sleep(0.5)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(0.5)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        await asyncio.sleep(0.5)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        await asyncio.sleep(0.5)
        await event.edit("`Wait.. Setting up Server Data`")
        
        try:
            # Eksekusi Script Bash
            z = subprocess.check_output(cmd, shell=True).decode("utf-8")
            
            # Tambahkan Footer Admin
            final_msg = f"""{z}
<b>» 👤 Telegram Admin : @HookageLegend</b>"""
            
            # Tampilkan Hasil dengan Mode HTML
            await event.edit(
                final_msg,
                parse_mode='html',
                buttons=[[Button.inline("‹ Main Menu ›", "menu")]]
            )
        except Exception as e:
            # Error Handling jika script bash gagal
            await event.edit(f"<b>❌ Error:</b> {str(e)}", buttons=[[Button.inline("‹ Main Menu ›", "menu")]], parse_mode='html')

    # Jalankan Proses
    await info_vps_process(event)