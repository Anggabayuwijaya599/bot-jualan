import requests
import json
from kyt.modules import config

# Base URL Endpoint Ramashop
BASE_URL = "https://ramashop.my.id/api/public"

# Kita ambil API Key dari config. Jika Anda belum mengganti nama variabelnya
# di config.py, ini akan tetap memakai config.ATLANTIC_KEY. 
# Sangat disarankan untuk mengubahnya nanti menjadi config.RAMASHOP_KEY
try:
    API_KEY = config.RAMASHOP_KEY.strip()
except AttributeError:
    API_KEY = config.ATLANTIC_KEY.strip()

def get_headers():
    """Header baru sesuai dokumentasi Ramashop"""
    return {
        'X-API-Key': API_KEY,
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
    }

def get_saldo():
    """Fungsi tambahan untuk cek saldo Ramashop (opsional)"""
    try:
        r = requests.get(f"{BASE_URL}/balance", headers=get_headers(), timeout=10)
        return r.json()
    except Exception as e:
        print(f"[RAMASHOP ERROR] Get Saldo: {e}")
        return {'status': False, 'message': str(e)}

def get_metode_pembayaran():
    """
    Di Ramashop, metode pembayaran utama adalah QRIS.
    Endpoint list metode tidak ada di doc, jadi kita buat mock (data tiruan)
    agar menu bot Anda tidak error jika membutuhkan list metode.
    """
    return [{"kode": "qris", "nama": "QRIS (Otomatis)"}]

def create_deposit(reff_id, nominal, tipe=None, metode="qris"):
    """
    Membuat deposit baru.
    Parameter reff_id dan tipe tetap dibiarkan agar tidak merusak kode di bot (main.py),
    meskipun Ramashop tidak membutuhkannya.
    """
    try:
        payload = {
            'amount': int(nominal),
            'method': str(metode).lower() if metode else "qris"
        }
        
        print(f"\n[RAMASHOP] Mencoba Topup: {nominal} via {metode}")
        r = requests.post(f"{BASE_URL}/deposit/create", json=payload, headers=get_headers(), timeout=15)
        
        try:
            res = r.json()
            # Ramashop menggunakan key 'success', Atlantic menggunakan 'status'.
            # Kita mapping 'success' menjadi 'status' agar bot Anda tetap bisa membacanya tanpa ubah kode lain.
            if 'success' in res:
                res['status'] = res['success']
        except:
            res = {'status': False, 'message': 'Server Error (Non-JSON)'}

        return res

    except Exception as e:
        print(f"[RAMASHOP SYSTEM ERROR] {e}")
        return {"status": False, "message": str(e)}

def check_status(id_deposit):
    """Mengecek status transaksi QRIS secara real-time"""
    try:
        # Menggunakan endpoint GET dengan id_deposit di URL
        url = f"{BASE_URL}/deposit/status/{id_deposit}"
        r = requests.get(url, headers=get_headers(), timeout=10)
        res = r.json()
        
        # Ramashop mengembalikan {"status": true, "data": {"status": "success"/"pending"}}
        return res
    except Exception as e:
        print(f"[RAMASHOP ERROR] Check Status: {e}")
        return {'status': False, 'message': str(e)}

def req_instant_deposit(id_deposit, action='true'):
    """
    Fitur ini tidak ada di dokumentasi Ramashop.
    Saya biarkan sebagai stub agar bot tidak error jika suatu saat terpanggil.
    """
    return {"status": False, "message": "Fitur Instant Deposit tidak didukung oleh sistem baru."}
    
def create_transfer(ref_id, kode_bank, nomor_akun, nama_pemilik, nominal, note="Withdraw Admin"):
    """
    Endpoint transfer bank belum ada di dokumentasi Ramashop.
    Dibiarkan sebagai stub agar tidak error.
    """
    return {"status": False, "message": "Fitur Transfer/Withdraw belum didukung oleh sistem baru."}