import requests
import json
from kyt.modules import config

# URL Endpoint
URL_METODE = "https://atlantich2h.com/deposit/metode"
URL_CREATE = "https://atlantich2h.com/deposit/create"
URL_STATUS = "https://atlantich2h.com/deposit/status"
URL_INSTANT = "https://atlantich2h.com/deposit/instant" # <--- Endpoint Baru

def get_headers(json_mode=False):
    if json_mode:
        return {
            'Content-Type': 'application/json',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
        }
    else:
        return {
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
        }

def get_metode_pembayaran():
    try:
        payload = {
            'api_key': config.ATLANTIC_KEY.strip(),
            'status': 'aktif'
        }
        r = requests.post(URL_METODE, data=payload, headers=get_headers(), timeout=10)
        res = r.json()
        if res.get('status') == True: 
            return res.get('data', [])
        return []
    except Exception as e:
        print(f"[ATLANTIC ERROR] Get Metode: {e}")
        return []

def create_deposit(reff_id, nominal, tipe, metode):
    try:
        api_key = config.ATLANTIC_KEY.strip()
        payload = {
            'api_key': api_key,
            'reff_id': str(reff_id),
            'nominal': int(nominal),
            'type': str(tipe),
            'metode': str(metode) 
        }
        
        print(f"\n[ATLANTIC] Mencoba Topup: {nominal} via {metode}")
        r = requests.post(URL_CREATE, data=payload, headers=get_headers(False), timeout=15)
        
        try:
            res = r.json()
        except:
            res = {'status': False, 'message': 'Server Error (Non-JSON)'}

        return res

    except Exception as e:
        print(f"[ATLANTIC SYSTEM ERROR] {e}")
        return {"status": False, "message": str(e)}

def check_status(id_deposit):
    """Mengecek status transaksi"""
    try:
        api_key = config.ATLANTIC_KEY.strip()
        payload = {
            'api_key': api_key,
            'id': str(id_deposit)
        }
        r = requests.post(URL_STATUS, data=payload, headers=get_headers(False), timeout=10)
        res = r.json()
        return res
    except Exception as e:
        print(f"[ATLANTIC ERROR] Check Status: {e}")
        return {'status': False, 'message': str(e)}

def req_instant_deposit(id_deposit, action='true'):
    """Melakukan Request Instant (Pencairan Paksa)"""
    try:
        api_key = config.ATLANTIC_KEY.strip()
        
        # Payload sesuai dokumentasi instant
        payload = {
            'api_key': api_key,
            'id': str(id_deposit),
            'action': action # 'true' untuk cairkan, 'false' cek biaya
        }
        
        print(f"[ATLANTIC] Request Instant Deposit ID: {id_deposit}")
        
        r = requests.post(URL_INSTANT, data=payload, headers=get_headers(False), timeout=15)
        res = r.json()
        
        return res
    except Exception as e:
        print(f"[ATLANTIC ERROR] Instant Deposit: {e}")
        return {'status': False, 'message': str(e)}
        
def create_transfer(ref_id, kode_bank, nomor_akun, nama_pemilik, nominal, note="Withdraw Admin"):
    url = "https://atlantich2h.com/transfer/create"
    payload = {
        'api_key': config.ATLANTIC_KEY.strip(),
        'ref_id': ref_id,
        'kode_bank': kode_bank,
        'nomor_akun': nomor_akun,
        'nama_pemilik': nama_pemilik,
        'nominal': nominal,
        'note': note
    }
    try:
        r = requests.post(url, data=payload, headers={'Content-Type': 'application/x-www-form-urlencoded'}, timeout=15)
        return r.json()
    except Exception as e:
        return {"status": False, "message": str(e)}