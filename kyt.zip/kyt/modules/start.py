from kyt import *
import os
import subprocess
from telethon import events
from telethon.tl.custom import Button
from kyt.modules import config
from kyt.modules import database

database.init_db()
print("✅ Database Connected & Initialized!")

# --- KONFIGURASI ---
OWNER_ID = config.OWNER_ID

def get_admin_from_var():
    # Pastikan path ini benar (sesuai letak file var.txt Anda)
    # Biasanya ada di /root/var.txt atau /usr/bin/kyt/var.txt
    var_path_list = ["/root/var.txt", "/usr/bin/kyt/var.txt"]
    admin_id = ""
    
    for var_file in var_path_list:
        if os.path.exists(var_file):
            try:
                with open(var_file, "r") as f:
                    lines = f.readlines()
                    for line in lines:
                        if line.startswith("ADMIN="):
                            # Ambil isi setelah ADMIN= dan hilangkan kutip
                            admin_id = line.strip().split("=")[1].replace('"', '')
                            return admin_id
            except:
                pass
    return admin_id

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    sender = await event.get_sender()
    chat_id = str(sender.id)
    first_name = sender.first_name
    
    is_callback = isinstance(event, events.CallbackQuery.Event)

    # --- CEK STATUS USER (LOGIKA MULTI ADMIN) ---
    status_user = "👤 GUEST / USER"
    val = valid(chat_id)
    
    # 1. Ambil Owner dari Config (Pisahkan jika ada koma)
    list_owners = [x.strip() for x in str(OWNER_ID).split(',')]
    
    # 2. Ambil Admin dari var.txt (Pisahkan jika ada koma)
    admin_var_str = get_admin_from_var()
    list_admins_var = [x.strip() for x in str(admin_var_str).split(',')]
    
    # 3. Gabungkan semua ID yang berhak jadi Admin
    ALL_AUTHORIZED = list_owners + list_admins_var

    # 4. Cek apakah ID pengirim ada di daftar?
    if chat_id in ALL_AUTHORIZED:
        val = "true"
        status_user = "👑 ADMIN / OWNER"
    elif val == "true":
         status_user = "💼 RESELLER / VIP"

    # --- LOGIKA TOMBOL DINAMIS ---
    inline = []
    
    # JIKA ADMIN / OWNER / RESELLER
    if status_user == "👑 ADMIN / OWNER" or status_user == "💼 RESELLER / VIP":
        inline.append([Button.inline("⚡ OPEN DASHBOARD PANEL", "menu")])
        inline.append([
            Button.url("💬 Whats App ", "https://wa.me/6283169627250"),
            Button.url("🛒 ORDER SCRIPT", "https://t.me/SinggahPremium")
        ])
    # JIKA USER BIASA
    else:
        # Tambahkan tombol Menu agar user bisa masuk store
        inline.append([Button.inline("🛒 MENU UTAMA / BELI", "menu")])
        inline.append([
            Button.url("💬 Whats App ", "https://wa.me/6283169627250"),
            Button.url("👨‍💻 KONTAK ADMIN", "https://t.me/SinggahPremium")
        ])

    # --- AMBIL INFO SERVER ---
    try:
        sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
        ssh = subprocess.check_output(sh, shell=True).decode("ascii").strip()
        
        sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
        namaos = subprocess.check_output(sdss, shell=True).decode("ascii").strip().replace('"','')
        
        ipvps = f" curl -s ipv4.icanhazip.com"
        ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii").strip()
        
        citsy = f" cat /etc/xray/city"
        city = subprocess.check_output(citsy, shell=True).decode("ascii").strip()
    except Exception as e:
        namaos = "Ubuntu"
        city = "Unknown"
        ipsaya = "127.0.0.1"

    # --- TAMPILAN PESAN HTML ---
    msg = f"""
<b>🌋 SINGGAH VPN STORE</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
👋 <b>Halo, {first_name}!</b>
<i>Selamat datang di Premium Management Panel.</i>
<b>👤 USER INFORMATION</b>
┌──────────────────────────────
│ <b>🆔 Telegram ID</b> : <code>{chat_id}</code>
│ <b>🏷️ Access Role</b> : <code>{status_user}</code>
└──────────────────────────────
<b>💻 SERVER INFORMATION</b>
┌──────────────────────────────
│ <b>⚙️ OS System</b>    : <code>{namaos}</code>
│ <b>📍 Location</b>     : <code>{city}</code>
│ <b>📡 Public IP</b>    : <code>{ipsaya}</code>
│ <b>🌐 Domain</b>       : <code>{DOMAIN}</code>
└──────────────────────────────
"""
    
    if is_callback:
        await event.edit(msg, buttons=inline, parse_mode='html')
    else:
        await event.reply(msg, buttons=inline, parse_mode='html')